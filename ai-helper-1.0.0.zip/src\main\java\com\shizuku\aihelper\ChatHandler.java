package com.shizuku.aihelper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.ClientChatEvent;

/**
 * 普通的聊天消息直接发给助手（不需要斜杠），以 / 开头的原版命令放行。
 * 有命令待确认时，只接管 y / n。
 */
public final class ChatHandler {
    private static String pendingCommand = null;

    private ChatHandler() {
    }

    public static void onChat(ClientChatEvent event) {
        AiConfig cfg = AiConfig.get();
        String raw = event.getMessage();

        // 1) 有待确认的命令：只认 y / n
        if (pendingCommand != null) {
            String key = raw.trim().toLowerCase();
            if (key.equals("y") || key.equals("yes") || key.equals("是") || key.equals("好")) {
                event.setCanceled(true);
                execute(pendingCommand);
                pendingCommand = null;
                return;
            }
            if (key.equals("n") || key.equals("no") || key.equals("不") || key.equals("取消")) {
                event.setCanceled(true);
                pendingCommand = null;
                feedback("§7取消啦");
                return;
            }
        }

        // 2) 以 / 开头的是原版命令，放行
        if (raw.startsWith("/")) {
            return;
        }

        // 3) chatMode=false 时，只有 prefix 开头的消息才交给助手
        String text = raw.trim();
        if (!cfg.chatMode) {
            String prefix = cfg.prefix == null || cfg.prefix.isBlank() ? "/ai" : cfg.prefix.trim();
            if (!text.startsWith(prefix)) {
                return;
            }
            text = text.substring(prefix.length()).trim();
        }

        if (text.isEmpty()) {
            return;
        }

        event.setCanceled(true);
        if (!cfg.ready()) {
            feedback("还没配置 API Key：打开 config/aihelper.json 把 apiKey 填上，然后重启游戏");
            return;
        }

        feedback("§7你：" + text);
        AiService.chat(text)
                .thenAccept(reply -> Minecraft.getInstance().execute(() -> handleReply(reply)))
                .exceptionally(err -> {
                    Minecraft.getInstance().execute(() -> feedback("§c请求失败：" + err.getMessage()));
                    return null;
                });
    }

    private static void handleReply(String rawReply) {
        JsonObject obj;
        try {
            obj = JsonParser.parseString(stripFences(rawReply)).getAsJsonObject();
        } catch (Exception e) {
            feedback("§c模型返回的不是 JSON：" + shorten(rawReply));
            return;
        }

        String reply = obj.has("reply") ? obj.get("reply").getAsString().trim() : "";
        String command = obj.has("command") ? obj.get("command").getAsString().trim() : "";

        if (!reply.isEmpty()) {
            feedback(reply);
        }

        if (command.isEmpty()) {
            return;
        }
        while (command.startsWith("/")) {
            command = command.substring(1);
        }

        AiConfig cfg = AiConfig.get();
        if (!cfg.isAllowed(command)) {
            feedback("§c当前权限等级不允许执行：/" + command);
            return;
        }

        if (cfg.requireConfirm) {
            pendingCommand = command;
            feedback("§7要执行：§e/" + command + " §7——输 y 确认，n 取消");
        } else {
            execute(command);
        }
    }

    private static void execute(String command) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) {
            feedback("§c不在游戏里，没法执行");
            return;
        }
        mc.player.connection.sendCommand(command);
        feedback("§a已执行：§e/" + command);
    }

    private static void feedback(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal("§b小月§r " + text), false);
        }
    }

    private static String stripFences(String text) {
        String t = text.trim();
        if (t.startsWith("```")) {
            t = t.replaceFirst("^```[a-zA-Z]*\\s*", "");
            if (t.endsWith("```")) {
                t = t.substring(0, t.length() - 3);
            }
        }
        return t.trim();
    }

    private static String shorten(String text) {
        String t = text == null ? "" : text.replace('\n', ' ');
        return t.length() > 120 ? t.substring(0, 120) + "…" : t;
    }
}
