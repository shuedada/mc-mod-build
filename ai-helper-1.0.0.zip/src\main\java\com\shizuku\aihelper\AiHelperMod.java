package com.shizuku.aihelper;

import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

/**
 * 入口：注册聊天拦截。
 * 用法：在聊天框输入 /ai 你的需求
 */
@Mod(AiHelperMod.MODID)
public final class AiHelperMod {
    public static final String MODID = "aihelper";
    public static final Logger LOGGER = LogUtils.getLogger();

    public AiHelperMod() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            MinecraftForge.EVENT_BUS.addListener(AiHelperMod::onChat);
            LOGGER.info("AI Helper loaded — 聊天框输入 /ai <需求>");
        }
    }

    private static void onChat(ClientChatEvent event) {
        ChatHandler.onChat(event);
    }
}
