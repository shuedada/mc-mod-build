package com.shizuku.aihelper;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 小月的背包界面：统一深色底，靠槽位边框区分。 */
public class XiaoyueBagScreen extends AbstractContainerScreen<XiaoyueBagMenu> {
    public XiaoyueBagScreen(XiaoyueBagMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 210;
        this.inventoryLabelY = 116;
        this.titleLabelY = 8;
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos;
        int y = this.topPos;

        // 统一深色底板 + 外框
        g.fill(x, y, x + this.imageWidth, y + this.imageHeight, 0xFF1E1E1E);
        g.fill(x, y, x + this.imageWidth, y + 1, 0xFFB0B0B0);
        g.fill(x, y + this.imageHeight - 1, x + this.imageWidth, y + this.imageHeight, 0xFFB0B0B0);
        g.fill(x, y, x + 1, y + this.imageHeight, 0xFFB0B0B0);
        g.fill(x + this.imageWidth - 1, y, x + this.imageWidth, y + this.imageHeight, 0xFFB0B0B0);

        // 槽位：深底 + 亮边，边界清楚
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                slotBox(g, x + 8 + col * 18, y + 26 + row * 18);
            }
        }
        for (int col = 0; col < 9; col++) {
            slotBox(g, x + 8 + col * 18, y + 186);
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                slotBox(g, x + 8 + col * 18, y + 128 + row * 18);
            }
        }
        int[] equipX = {8, 62, 80, 98, 116};
        for (int ex : equipX) {
            slotBox(g, x + ex, y + 100);
        }

        g.drawString(this.font, "小月的背包", x + 8, y + 9, 0xFFFFFFFF, false);
        g.drawString(this.font, "装备", x + 8, y + 90, 0xFFC0C0C0, false);
    }

    /** 一个 18x18 的槽位：深底 + 一圈稍亮的边 */
    private void slotBox(GuiGraphics g, int sx, int sy) {
        g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF3C3C3C);
        g.fill(sx, sy, sx + 16, sy + 16, 0xFF0E0E0E);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        this.renderTooltip(g, mouseX, mouseY);
    }
}
