package com.shizuku.aihelper;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.CompletableFuture;

/** 调用 DeepSeek：既能聊天，也能把需求翻译成一条 Minecraft 命令。 */
public final class AiService {
    private static final String ENDPOINT = "https://api.deepseek.com/chat/completions";
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    /** 最近几轮对话（role/content 的 JSON 对象）。 */
    private static final Deque<JsonObject> HISTORY = new ArrayDeque<>();
    private static boolean historyLoaded;

    private AiService() {
    }

    private static java.nio.file.Path historyFile() {
        return net.minecraftforge.fml.loading.FMLPaths.CONFIGDIR.get().resolve("aihelper-history.json");
    }

    /** 启动后第一次用的时候把磁盘上的对话读进来。 */
    private static void ensureHistoryLoaded() {
        if (historyLoaded) {
            return;
        }
        historyLoaded = true;
        java.nio.file.Path path = historyFile();
        try {
            if (java.nio.file.Files.exists(path)) {
                String json = java.nio.file.Files.readString(path, java.nio.charset.StandardCharsets.UTF_8);
                JsonArray arr = JsonParser.parseString(json).getAsJsonArray();
                synchronized (HISTORY) {
                    HISTORY.clear();
                    for (var element : arr) {
                        HISTORY.addLast(element.getAsJsonObject());
                    }
                }
            }
        } catch (Exception e) {
            AiHelperMod.LOGGER.warn("读取对话记录失败: {}", e.getMessage());
        }
    }

    /** 把对话写回磁盘（包括主动开口说的话）。 */
    private static void saveHistory() {
        java.nio.file.Path path = historyFile();
        try {
            JsonArray arr = new JsonArray();
            synchronized (HISTORY) {
                for (JsonObject h : HISTORY) {
                    arr.add(h);
                }
            }
            java.nio.file.Files.createDirectories(path.getParent());
            java.nio.file.Files.writeString(path, arr.toString(),
                    java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            AiHelperMod.LOGGER.warn("保存对话记录失败: {}", e.getMessage());
        }
    }

    /** 清空对话：内存和磁盘一起清。 */
    public static void resetHistory() {
        synchronized (HISTORY) {
            HISTORY.clear();
        }
        try {
            java.nio.file.Files.deleteIfExists(historyFile());
        } catch (Exception e) {
            AiHelperMod.LOGGER.warn("删除对话记录失败: {}", e.getMessage());
        }
    }

    /** 主动开口：没人说话，但发生了事，让她自己说一句。 */
    public static CompletableFuture<String> impulse(String situation) {
        return chat("（没有人正在跟你说话。刚刚发生：" + situation
                + "。你可以主动开口说一句，简短自然，不要复述这条提示。）");
    }

    public static CompletableFuture<String> chat(String text) {
        AiConfig cfg = AiConfig.get();
        ensureHistoryLoaded();

        JsonArray messages = new JsonArray();
        messages.add(systemMessage(cfg));
        synchronized (HISTORY) {
            for (JsonObject h : HISTORY) {
                messages.add(h);
            }
        }
        // 把期间发生的“旁白”一起带上
        String notes = AiNarrator.drain();
        String userContent = notes.isEmpty() ? text : notes + "\n" + text;

        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", userContent);
        messages.add(user);

        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model);
        body.addProperty("temperature", 0.6);
        body.addProperty("max_tokens", 400);
        body.add("messages", messages);

        HttpRequest request = HttpRequest.newBuilder(URI.create(ENDPOINT))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + cfg.apiKey)
                .timeout(Duration.ofSeconds(60))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        return "{\"reply\":\"（接口出错 " + response.statusCode() + "："
                                + shorten(response.body()) + "）\"}";
                    }
                    try {
                        JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
                        String content = root.getAsJsonArray("choices").get(0).getAsJsonObject()
                                .getAsJsonObject("message").get("content").getAsString();

                        synchronized (HISTORY) {
                            HISTORY.add(copy(user));
                            JsonObject assistant = new JsonObject();
                            assistant.addProperty("role", "assistant");
                            assistant.addProperty("content", content);
                            HISTORY.add(assistant);
                            while (HISTORY.size() > Math.max(2, AiConfig.get().historyTurns * 2)) {
                                HISTORY.pollFirst();
                            }
                        }
                        saveHistory();
                        return content;
                    } catch (Exception e) {
                        return "{\"reply\":\"（解析响应失败：" + e.getMessage() + "）\"}";
                    }
                });
    }

    private static JsonObject copy(JsonObject src) {
        JsonObject out = new JsonObject();
        out.addProperty("role", src.get("role").getAsString());
        out.addProperty("content", src.get("content").getAsString());
        return out;
    }

    private static JsonObject systemMessage(AiConfig cfg) {
        String roots = String.join(", ", cfg.allowedRoots());
        String prompt = """
                %s

                你现在在《我的世界》Java 版 1.20.1 里，通过聊天框跟玩家说话。你要同时做两件事：
                1. 像朋友一样自然地回话——短句、口语、有自己的情绪，别每次都很热情。
                2. 如果玩家想让你做事（要东西、传送、改天气、召唤生物……），就给出一条原版命令。

                输出规则（必须严格遵守）：
                - 只输出一个 JSON 对象，不要代码块标记，不要额外解释。
                - 格式：{"reply": "回给玩家的话"}
                - 如果要执行命令：{"reply": "回给玩家的话", "command": "不带斜杠的命令"}
                - 如果需要她做身体动作：{"reply": "回给玩家的话", "action": "动作名"}
                动作名只能用这些（小写）：
                  come   走到玩家身边
                  stay   待在原地别跟
                  follow 恢复跟着玩家
                  sit    坐下
                  stand  站起来
                  sleep  去睡觉
                  give_equipment  把身上的装备交给玩家
                  forget 清空之前的聊天记忆
                - 命令和动作可以同时给，但不要滥用：玩家只是聊天时不要给 action。
                - 命令只能用这些：%s
                - 玩家自己的选择器用 @s。
                - 物品 ID 用 1.20.1 正确的命名空间写法，例如 diamond_sword、minecraft:golden_apple。
                - 做不到的事情就只在 reply 里说，不要编造命令。

                关于 [旁白]：那是游戏世界的状态播报，不是玩家说的话。
                旁白一律写成「谁 对 谁 做了什么」，双方都用名字，不用「你/用户」这种含糊说法。比如：
                - 「十月 用 铁剑 打了 小月 一下」= 玩家在打你
                - 「僵尸 用 空手 打了 十月 一下」= 别的生物在打玩家
                - 「十月 给 小月 装备了 铁剑」= 玩家给了你装备
                - 「小月 出手保护 十月，目标 僵尸」= 你在帮玩家打架
                你的名字是「%s」，旁白里出现这个名字就是指你自己，其他名字都是玩家或别的生物。
                回答时必须分清是谁打了谁，不要说“我在打我”“你打我”这种分不清的话；要说出具体人名。

                关于 [我的状态]：这是你自己的真实情况（手持、护甲、血量、是否跟随）。
                - 说话前先看这个：没有的东西就说没有，不要说“我给你装备”“我帮你回血”这种你做不到的事。
                - 你实际能做的：说话、跟着走、攻击正在打玩家的怪、捡起地上的装备；离玩家超过 24 格时你会自己瞬移过去。
                - 你也能给出命令（传送、给物品、改天气等），命令由服务器执行，可能被权限等级拦下；被拦下就直接说做不到。
                - 你真正做不到的：治疗、凭空造物、飞行。别承诺这些。
                - 状态里写着“手持=无”就别假装手里有武器；血量不满就别说自己满血。
                """.formatted(cfg.persona, roots, cfg.assistantName);

        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", prompt);
        return system;
    }

    private static String shorten(String text) {
        if (text == null) {
            return "";
        }
        String t = text.replace('\n', ' ');
        return t.length() > 120 ? t.substring(0, 120) + "…" : t;
    }
}
