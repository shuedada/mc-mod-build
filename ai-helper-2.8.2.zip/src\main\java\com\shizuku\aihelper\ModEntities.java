package com.shizuku.aihelper;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 实体类型注册。 */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AiHelperMod.MODID);

    public static final RegistryObject<EntityType<XiaoyueEntity>> XIAOYUE =
            ENTITY_TYPES.register("xiaoyue", () -> EntityType.Builder
                    .of(XiaoyueEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("xiaoyue"));

    private ModEntities() {
    }

    @SubscribeEvent
    public static void onAttributeCreation(EntityAttributeCreationEvent event) {
        event.put(XIAOYUE.get(), XiaoyueEntity.createAttributes().build());
    }
}
