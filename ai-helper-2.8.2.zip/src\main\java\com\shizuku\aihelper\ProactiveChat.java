package com.shizuku.aihelper;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * 主动开口：世界里发生大事（被打、主人被打、刚打赢、装备变化）时，
 * 让她自己说一句，而不是等别人叫她。有冷却和开关，避免烧钱。
 */
public final class ProactiveChat {
    private static long lastFiredAt = 0L;
    private static long lastInstantAt = 0L;

    private ProactiveChat() {
    }

    /** 普通事件：受主动开口冷却限制。 */
    public static void fire(MinecraftServer server, ServerPlayer owner, String situation) {
        if (server == null) {
            return;
        }
        AiConfig cfg = AiConfig.get();
        if (!cfg.proactiveChat || !cfg.ready()) {
            return;
        }
        long now = System.currentTimeMillis();
        long cooldown = Math.max(5, cfg.proactiveCooldownSeconds) * 1000L;
        synchronized (ProactiveChat.class) {
            if (now - lastFiredAt < cooldown) {
                return;
            }
            lastFiredAt = now;
        }
        dispatch(server, owner, situation);
    }

    /** 装备变化这类“一定要回一句”的场合：不受主冷却限制，但至少间隔 4 秒。 */
    public static void fireNow(MinecraftServer server, ServerPlayer owner, String situation) {
        if (server == null) {
            return;
        }
        AiConfig cfg = AiConfig.get();
        if (!cfg.proactiveChat || !cfg.ready()) {
            return;
        }
        long now = System.currentTimeMillis();
        synchronized (ProactiveChat.class) {
            if (now - lastInstantAt < 4000L) {
                return;
            }
            lastInstantAt = now;
            lastFiredAt = now;
        }
        dispatch(server, owner, situation);
    }

    private static void dispatch(MinecraftServer server, ServerPlayer owner, String situation) {
        AiNarrator.note(situation);
        AiService.impulse(situation)
                .thenAccept(reply -> server.execute(() -> ServerChatHandler.proactiveReply(server, owner, reply)))
                .exceptionally(err -> null);
    }
}
