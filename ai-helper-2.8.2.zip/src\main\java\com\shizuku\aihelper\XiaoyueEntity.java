package com.shizuku.aihelper;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * 小月的实体：玩家大小、会看向你、可以跟着你走或者站在原地。
 */
public class XiaoyueEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> DATA_FOLLOWING =
            SynchedEntityData.defineId(XiaoyueEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> DATA_SAY =
            SynchedEntityData.defineId(XiaoyueEntity.class, EntityDataSerializers.STRING);

    @Nullable
    private UUID ownerUuid;
    private int idleTicks;
    private String lastEquipmentSig = "";
    private boolean selfEquip;
    private int lastOwnerHurtTime;
    private long lastFarNoteAt;

    public XiaoyueEntity(EntityType<? extends XiaoyueEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setCanPickUpLoot(true);
        this.xpReward = 0;

        // 头顶只显示名字，不要那一长串翻译键
        String display = AiConfig.get().assistantName;
        if (display == null || display.isBlank()) {
            display = "xiaoyue";
        }
        this.setCustomName(net.minecraft.network.chat.Component.literal(display));
        this.setCustomNameVisible(true);

        // 死亡时身上装备全部掉落
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            this.setDropChance(slot, 1.0F);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_FOLLOWING, Boolean.TRUE);
        this.entityData.define(DATA_SAY, "");
    }

    /** 头顶气泡要显示的话。 */
    public void setSay(String text) {
        String t = text == null ? "" : text.trim();
        if (t.length() > 60) {
            t = t.substring(0, 60) + "…";
        }
        this.entityData.set(DATA_SAY, t);
    }

    public String getSay() {
        return this.entityData.get(DATA_SAY);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F, 1.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.5D));
    }

    public boolean isFollowing() {
        return this.entityData.get(DATA_FOLLOWING);
    }

    public void setFollowing(boolean value) {
        this.entityData.set(DATA_FOLLOWING, value);
    }

    public void setOwner(@Nullable Player player) {
        this.ownerUuid = player == null ? null : player.getUUID();
    }

    @Nullable
    public Player getOwner() {
        if (this.ownerUuid == null) {
            return null;
        }
        return this.level().getPlayerByUUID(this.ownerUuid);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }

        // 附近没人的时候慢慢“消失”
        int vanishSeconds = AiConfig.get().idleVanishSeconds;
        if (vanishSeconds > 0) {
            boolean someoneNear = !this.level().getEntitiesOfClass(
                    Player.class,
                    this.getBoundingBox().inflate(8.0D),
                    p -> p.isAlive() && !p.isSpectator()).isEmpty();
            if (someoneNear) {
                this.idleTicks = 0;
            } else {
                this.idleTicks++;
                if (this.idleTicks > vanishSeconds * 20) {
                    this.discard();
                    return;
                }
            }
        }

        // 只打“正在打主人”的生物：每 20 tick 扫一次
        Player ownerForCombat = this.getOwner();
        if (ownerForCombat != null && ownerForCombat.isAlive() && this.tickCount % 20 == 0) {
            if (this.getTarget() == null || !this.getTarget().isAlive()) {
                Mob attacker = this.level().getEntitiesOfClass(Mob.class,
                                this.getBoundingBox().inflate(16.0D),
                                m -> m != this && m.isAlive() && m.getTarget() == ownerForCombat)
                        .stream().findFirst().orElse(null);
                if (attacker != null) {
                    this.setTarget(attacker);
                    AiNarrator.note(this.myName() + " 出手保护 " + ownerForCombat.getName().getString()
                            + "，目标 " + attacker.getName().getString());
                }
            }
        }

        Player owner = this.getOwner();
        if (owner == null || !owner.isAlive()) {
            return;
        }

        // 旁白：主人挨打 / 装备变化 / 距离太远
        if (owner.hurtTime > 0 && this.lastOwnerHurtTime == 0) {
            net.minecraft.world.entity.LivingEntity attacker = owner.getLastHurtByMob();
            String situation;
            if (attacker != null && attacker != this) {
                String who = attacker.getName().getString();
                net.minecraft.world.item.ItemStack weapon = attacker.getMainHandItem();
                String what = weapon.isEmpty() ? "空手" : weapon.getHoverName().getString();
                situation = who + " 用 " + what + " 打了 " + owner.getName().getString() + " 一下";
            } else {
                situation = owner.getName().getString() + " 受到了伤害";
            }
            AiNarrator.note(situation);
            ProactiveChat.fire(this.getServer(), this.ownerOrNull(), situation);
        }
        this.lastOwnerHurtTime = owner.hurtTime;

        // 装备变化：谁给的、给了什么，都记下来并回一句
        if (this.tickCount % 20 == 0) {
            String sig = this.equipmentSignature();
            if (!sig.equals(this.lastEquipmentSig)) {
                boolean first = this.lastEquipmentSig.isEmpty();
                this.lastEquipmentSig = sig;
                String who = owner.getName().getString();
                String me = this.myName();
                String desc = this.equipmentDescription();
                if (!first || !desc.isEmpty()) {
                    String situation;
                    if (this.selfEquip) {
                        situation = me + " 自己把 " + desc + " 捡起来装备上了";
                    } else if (desc.isEmpty()) {
                        situation = who + " 把 " + me + " 的装备全拿走了";
                    } else {
                        situation = who + " 给 " + me + " 装备了 " + desc;
                    }
                    this.selfEquip = false;
                    AiNarrator.note(situation);
                    ProactiveChat.fireNow(this.getServer(), this.ownerOrNull(), situation);
                }
            }
        }

        // 捡地上的装备：对应格子空着就直接穿上
        if (this.tickCount % 20 == 0) {
            for (net.minecraft.world.entity.item.ItemEntity drop :
                    this.level().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                            this.getBoundingBox().inflate(4.0D))) {
                if (!drop.isAlive()) {
                    continue;
                }
                net.minecraft.world.item.ItemStack stack = drop.getItem();
                net.minecraft.world.entity.EquipmentSlot slot =
                        Mob.getEquipmentSlotForItem(stack);
                if (slot == null || !this.getItemBySlot(slot).isEmpty()) {
                    continue;
                }
                this.selfEquip = true;
                this.setItemSlot(slot, stack.copy());
                this.setDropChance(slot, 1.0F);
                drop.discard();
            }
        }

        double distSq = this.distanceToSqr(owner);
        if (distSq > 576.0D) {
            long nowMs = System.currentTimeMillis();
            if (nowMs - this.lastFarNoteAt > 10_000L) {
                this.lastFarNoteAt = nowMs;
                AiNarrator.note(owner.getName().getString() + " 离 " + this.myName() + " 太远了");
            }
        }

        // 站定时不跟过去
        if (!this.isFollowing()) {
            return;
        }
        if (distSq > 576.0D) {
            if (this.tickCount % 40 == 0) {
                // 只有真的走丢（24 格以上）才传送，平时让她自己走
                this.teleportTo(owner.getX(), owner.getY(), owner.getZ());
                this.setDeltaMovement(0, 0, 0);
            }
        } else if (this.getTarget() == null) {
            // 3 格以内就停下，超过 3 格才跟过去；打架时不抢导航
            if (distSq > 9.0D) {
                if (this.tickCount % 10 == 0) {
                    this.getNavigation().moveTo(owner, 1.1D);
                }
            } else {
                this.getNavigation().stop();
            }
        }
    }

    /** 自己叫什么（取自配置，默认 xiaoyue）。 */
    private String myName() {
        String n = AiConfig.get().assistantName;
        return n == null || n.isBlank() ? "xiaoyue" : n;
    }

    /** 全身装备的指纹，用来判断有没有变化。 */
    private String equipmentSignature() {
        StringBuilder sb = new StringBuilder();
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            if (slot != net.minecraft.world.entity.EquipmentSlot.MAINHAND
                    && slot.getType() != net.minecraft.world.entity.EquipmentSlot.Type.ARMOR) {
                continue;
            }
            net.minecraft.world.item.ItemStack stack = this.getItemBySlot(slot);
            sb.append(stack.isEmpty() ? "-" : stack.getItem().toString()).append('|');
        }
        return sb.toString();
    }

    /** 把身上的装备说成一句话，比如“铁剑、铁头盔”。 */
    private String equipmentDescription() {
        StringBuilder sb = new StringBuilder();
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            if (slot != net.minecraft.world.entity.EquipmentSlot.MAINHAND
                    && slot.getType() != net.minecraft.world.entity.EquipmentSlot.Type.ARMOR) {
                continue;
            }
            net.minecraft.world.item.ItemStack stack = this.getItemBySlot(slot);
            if (stack.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append("、");
            }
            sb.append(stack.getHoverName().getString());
        }
        return sb.toString();
    }

    /** 主人（转成服务端玩家，可能为空）。 */
    @Nullable
    private net.minecraft.server.level.ServerPlayer ownerOrNull() {
        Player p = this.getOwner();
        return p instanceof net.minecraft.server.level.ServerPlayer sp ? sp : null;
    }

    /** 把身上装备全交出去，返回交出的件数。 */
    public int giveEquipmentTo(net.minecraft.server.level.ServerPlayer player) {
        int count = 0;
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            if (slot != net.minecraft.world.entity.EquipmentSlot.MAINHAND
                    && slot.getType() != net.minecraft.world.entity.EquipmentSlot.Type.ARMOR) {
                continue;
            }
            net.minecraft.world.item.ItemStack stack = this.getItemBySlot(slot);
            if (stack.isEmpty()) {
                continue;
            }
            this.setItemSlot(slot, net.minecraft.world.item.ItemStack.EMPTY);
            net.minecraft.world.item.ItemStack copy = stack.copy();
            if (!player.getInventory().add(copy)) {
                player.drop(copy, false);
            }
            count++;
        }
        return count;
    }

    /** 给模型看的自检报告：身上有什么、血多少、在不在跟随。 */
    public String statusLine() {
        return "手持=" + itemName(this.getMainHandItem())
                + "，头=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD))
                + "，胸=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST))
                + "，腿=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.LEGS))
                + "，靴=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.FEET))
                + "，血=" + (int) Math.ceil(this.getHealth()) + "/" + (int) this.getMaxHealth()
                + "，状态=" + (this.isFollowing() ? "跟随中" : "原地站着");
    }

    private static String itemName(net.minecraft.world.item.ItemStack stack) {
        return stack == null || stack.isEmpty() ? "无" : stack.getHoverName().getString();
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (source.getEntity() instanceof net.minecraft.world.entity.LivingEntity attacker && attacker != this) {
            String who = attacker.getName().getString();
            net.minecraft.world.item.ItemStack weapon = attacker.getMainHandItem();
            String what = weapon.isEmpty() ? "空手" : weapon.getHoverName().getString();
            String situation = who + " 用 " + what + " 打了 " + this.myName() + " 一下";
            AiNarrator.note(situation);
            ProactiveChat.fire(this.getServer(), this.ownerOrNull(), situation);
            // 挨打了就立刻往主人身边跑
            Player owner = this.getOwner();
            if (owner != null && this.isFollowing()) {
                this.getNavigation().moveTo(owner, 1.3D);
            }
        }
        return super.hurt(source, amount);
    }

    @Override
    public boolean killedEntity(net.minecraft.server.level.ServerLevel level,
                                net.minecraft.world.entity.LivingEntity victim) {
        boolean result = super.killedEntity(level, victim);
        String name = victim.getName().getString();
        AiNarrator.note(this.myName() + " 打倒了 " + name);
        ProactiveChat.fire(level.getServer(), this.ownerOrNull(), this.myName() + " 刚打倒了 " + name);
        return result;
    }

    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        AiNarrator.note(this.myName() + " 被打倒了");
        super.die(source);
    }

    /** 「过来」：走向某个玩家 */
    public void comeTo(Player target) {
        this.setFollowing(true);
        this.getNavigation().moveTo(target, 1.2D);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Following", this.isFollowing());
        if (this.ownerUuid != null) {
            tag.putUUID("Owner", this.ownerUuid);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Following")) {
            this.setFollowing(tag.getBoolean("Following"));
        }
        if (tag.hasUUID("Owner")) {
            this.ownerUuid = tag.getUUID("Owner");
        }
    }
}
