package com.shizuku.aihelper;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * 旁白：把世界里发生的事记下来（谁给了武器、谁在挨打、离得太远……），
 * 下次和 AI 说话时一起带上，让她“知道刚才发生了什么”。
 */
public final class AiNarrator {
    private static final Deque<String> NOTES = new ArrayDeque<>();
    private static final int MAX_NOTES = 20;

    private AiNarrator() {
    }

    /** 记一条旁白，比如 note("用户给了你一把铁剑") */
    public static void note(String text) {
        if (text == null || text.isBlank()) {
            return;
        }
        synchronized (NOTES) {
            NOTES.addLast(text.trim());
            while (NOTES.size() > MAX_NOTES) {
                NOTES.removeFirst();
            }
        }
    }

    /** 取走并清空。返回 "[旁白] a；b；c"，没有就返回空串。 */
    public static String drain() {
        synchronized (NOTES) {
            if (NOTES.isEmpty()) {
                return "";
            }
            String joined = String.join("；", NOTES);
            NOTES.clear();
            return "[旁白] " + joined;
        }
    }

    public static void clear() {
        synchronized (NOTES) {
            NOTES.clear();
        }
    }
}
