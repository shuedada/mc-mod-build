package com.shizuku.aihelper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 配置：config/aihelper.json
 * 游戏内可以用 /aiconfig 打开图形界面修改。
 */
public final class AiConfig {
    public String apiKey = "";
    public String model = "deepseek-chat";
    /** chatMode=true：聊天框里直接说话就是跟助手聊；false：只有 /ai 开头的消息才算 */
    public boolean chatMode = true;
    /** true=你的话照常发给服务器，同时也给助手看；false=只给助手看 */
    public boolean forwardChat = false;
    /** 助手回复的广播方式：off=只自己看，tellraw=其他玩家也能看到 <名字> 内容（需要 OP） */
    public String broadcast = "tellraw";
    /** 兜底前缀，chatMode=false 时用 */
    public String prefix = "/ai";
    /** 1=安全 2=常规 3=全开 */
    public int permissionLevel = 2;
    /** true=执行命令前需要在聊天框敲 y 确认 */
    public boolean requireConfirm = true;
    /** 记忆最近几轮对话（20 轮约 1200 token，一次对话成本约一分钱的五分之一） */
    public int historyTurns = 20;
    /** 附近没玩家超过这么多秒就消失（0 = 永不消失） */
    public int idleVanishSeconds = 60;
    /** 被打/主人挨打时，让她自己主动开口（每次都会调用一次 API，费钱） */
    public boolean proactiveChat = true;
    /** 主动开口的最小间隔（秒） */
    public int proactiveCooldownSeconds = 20;
    /** 主动开口时允许她执行命令（有风险：可能在你没要求时传送你） */
    public boolean proactiveAllowCommand = false;
    /** true=必须叫名字才理你；false=聊天框里任何一句话都算跟她说话（会变贵） */
    public boolean requireName = true;
    /** 助手人设，可以自己改 */
    public String persona = "你叫小月，是玩家在《我的世界》里的 AI 助手。语气慵懒、简短、有自己的脾气，偶尔损人但不刻薄。";
    /** 助手名字，只在 showName=true 时才显示 */
    public String assistantName = "xiaoyue";
    /** 每条回复前是否加助手名字 */
    public boolean showName = true;
    /** permissionLevel 为 0 时使用这个白名单（只写命令根，如 give） */
    public List<String> allowedCommands = new ArrayList<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static AiConfig instance;

    public static AiConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public static void save() {
        if (instance == null) {
            return;
        }
        Path path = file();
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(instance), StandardCharsets.UTF_8);
        } catch (IOException e) {
            AiHelperMod.LOGGER.error("保存配置失败: {}", e.getMessage());
        }
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("aihelper.json");
    }

    private static AiConfig load() {
        Path path = file();
        Path legacy = FMLPaths.CONFIGDIR.get().resolve("xiaoyuehelper.json");
        AiConfig cfg = new AiConfig();
        try {
            // 从临时用过的名字迁移回来
            if (!Files.exists(path) && Files.exists(legacy)) {
                Files.copy(legacy, path);
            }
            if (Files.exists(path)) {
                String json = Files.readString(path, StandardCharsets.UTF_8);
                AiConfig parsed = GSON.fromJson(json, AiConfig.class);
                if (parsed != null) {
                    if (parsed.model == null) parsed.model = cfg.model;
                    if (parsed.prefix == null) parsed.prefix = cfg.prefix;
                    if (parsed.persona == null) parsed.persona = cfg.persona;
                    if (parsed.broadcast == null) parsed.broadcast = cfg.broadcast;
                    if (parsed.allowedCommands == null) parsed.allowedCommands = cfg.allowedCommands;
                    if (parsed.historyTurns <= 0) parsed.historyTurns = cfg.historyTurns;
                    cfg = parsed;
                }
            } else {
                Files.createDirectories(path.getParent());
                Files.writeString(path, GSON.toJson(cfg), StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            AiHelperMod.LOGGER.error("读取配置失败: {}", e.getMessage());
        }
        return cfg;
    }

    public boolean ready() {
        return apiKey != null && !apiKey.isBlank();
    }

    /** 当前权限等级允许的命令根。 */
    public List<String> allowedRoots() {
        if (permissionLevel <= 0) {
            return allowedCommands;
        }
        List<String> roots = new ArrayList<>(List.of("give", "tp", "time", "weather", "gamemode", "say", "me"));
        if (permissionLevel >= 2) {
            roots.addAll(List.of("summon", "effect", "enchant", "fill", "setblock", "clear", "xp", "particle", "playsound", "locate"));
        }
        if (permissionLevel >= 3) {
            roots.addAll(List.of("kill", "execute", "clone", "data", "tag", "scoreboard", "item", "ride", "spreadplayers", "difficulty", "gamerule"));
        }
        return roots;
    }

    public boolean isAllowed(String command) {
        String root = rootOf(command);
        if (permissionLevel >= 3) {
            return !List.of("stop", "op", "deop", "ban", "ban-ip", "pardon", "whitelist", "save-off").contains(root);
        }
        return allowedRoots().contains(root);
    }

    private static String rootOf(String command) {
        String c = command.trim();
        while (c.startsWith("/")) {
            c = c.substring(1);
        }
        int space = c.indexOf(' ');
        return (space > 0 ? c.substring(0, space) : c).toLowerCase();
    }

    public static Gson gson() {
        return GSON;
    }
}
