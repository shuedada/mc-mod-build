package com.shizuku.aihelper;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/** 客户端：头顶气泡 + 右键打开对话。 */
@Mod.EventBusSubscriber(modid = AiHelperMod.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {
    }

    /** 她说的话在她头顶显示成气泡 */
    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Post<?, ?> event) {
        if (!(event.getEntity() instanceof XiaoyueEntity entity)) {
            return;
        }
        String text = entity.getSay();
        if (text == null || text.isBlank()) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        PoseStack pose = event.getPoseStack();
        MultiBufferSource buffer = event.getMultiBufferSource();
        Font font = mc.font;

        pose.pushPose();
        pose.translate(0.0D, entity.getBbHeight() + 0.55D, 0.0D);
        pose.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
        pose.scale(-0.025F, -0.025F, 0.025F);

        Matrix4f matrix = pose.last().pose();
        float width = font.width(text);
        int bg = (int) (mc.options.getBackgroundOpacity(0.3F) * 255.0F) << 24;

        font.drawInBatch(text, -width / 2.0F, 0.0F, 0xFFFFFFFF, false, matrix, buffer,
                Font.DisplayMode.SEE_THROUGH, bg, event.getPackedLight());

        pose.popPose();
    }

    /** 右键她 → 打开对话界面 */
    @SubscribeEvent
    public static void onUseKey(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || !event.isUseItem()) {
            return;
        }
        if (mc.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof XiaoyueEntity) {
            event.setCanceled(true);
            mc.setScreen(new XiaoyueChatScreen());
        }
    }
}
