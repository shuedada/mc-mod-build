package com.shizuku.aihelper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;

import java.util.UUID;

/** 右键小月打开的对话界面。 */
public class XiaoyueChatScreen extends Screen {
    private EditBox field;

    public XiaoyueChatScreen() {
        super(Component.literal("说话"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int fieldWidth = Math.min(300, this.width - 40);
        int top = this.height / 2 - 20;

        this.field = new EditBox(this.font, cx - fieldWidth / 2, top, fieldWidth, 20,
                Component.literal("说话"));
        this.field.setMaxLength(200);
        this.addRenderableWidget(this.field);
        this.setInitialFocus(this.field);

        this.addRenderableWidget(Button.builder(Component.literal("说"), b -> send())
                .bounds(cx - 40, top + 28, 80, 20).build());
    }

    private void send() {
        String text = this.field == null ? "" : this.field.getValue().trim();
        if (text.isEmpty()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            onClose();
            return;
        }

        MinecraftServer server = mc.getSingleplayerServer();
        if (server != null) {
            // 单人/局域网主机：直接交给服务端逻辑，不用打字到公共聊天里
            UUID id = mc.player.getUUID();
            server.execute(() -> ServerChatHandler.askFromGui(server, id, text));
        } else {
            // 在别人的服务器：只能走聊天，必要时补上名字
            AiConfig cfg = AiConfig.get();
            String payload = cfg.requireName ? (cfg.assistantName + " " + text) : text;
            mc.player.connection.sendChat(payload);
        }
        onClose();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // Enter
            send();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 44, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, Component.literal("回车发送 · ESC 关闭"),
                this.width / 2, this.height / 2 + 60, 0x808080);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(null);
    }
}
