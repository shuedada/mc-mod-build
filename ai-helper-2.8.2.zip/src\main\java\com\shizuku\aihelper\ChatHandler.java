package com.shizuku.aihelper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.ClientChatEvent;

/**
 * 聊天拦截 + 命令执行。
 * - 直接聊天模式下，普通消息交给助手（是否同时发给服务器看 forwardChat）
 * - 关闭直接聊天后，用 /<助手名字> 你的话 触发（客户端命令）
 */
public final class ChatHandler {
    private static String pendingCommand = null;

    private ChatHandler() {
    }

    public static void onChat(ClientChatEvent event) {
        AiConfig cfg = AiConfig.get();
        String raw = event.getMessage();

        // 自己开的世界：交给服务端逻辑处理，客户端不插手（避免重复回两遍）
        if (Minecraft.getInstance().hasSingleplayerServer()) {
            return;
        }

        // 0) /aiconfig 兜底（有些版本能被拦截，多数不行；真正的入口是 K 键）
        if (raw.trim().equalsIgnoreCase("/aiconfig")) {
            event.setCanceled(true);
            Minecraft.getInstance().execute(() -> Minecraft.getInstance().setScreen(new ConfigScreen(null)));
            return;
        }

        // 1) 有待确认的命令：只认 y / n
        if (pendingCommand != null) {
            String key = raw.trim().toLowerCase();
            if (key.equals("y") || key.equals("yes") || key.equals("是") || key.equals("好")) {
                event.setCanceled(true);
                execute(pendingCommand);
                pendingCommand = null;
                return;
            }
            if (key.equals("n") || key.equals("no") || key.equals("不") || key.equals("取消")) {
                event.setCanceled(true);
                pendingCommand = null;
                notice("§7取消啦");
                return;
            }
        }

        // 2) 以 / 开头的是原版命令，放行
        if (raw.startsWith("/")) {
            return;
        }

        // 3) 关闭直接聊天时，普通消息不管
        if (!cfg.chatMode) {
            return;
        }

        String text = raw.trim();
        if (text.isEmpty()) {
            return;
        }

        boolean forward = cfg.forwardChat;
        if (!forward) {
            event.setCanceled(true);
            notice(vanillaEcho(text));
        }
        ask(text);
    }

    /** 客户端命令 /<名字> 你的话 走这里。 */
    public static void ask(String text) {
        AiConfig cfg = AiConfig.get();
        String clean = text == null ? "" : text.trim();
        if (clean.isEmpty()) {
            notice("§7说点什么吧");
            return;
        }
        if (!cfg.ready()) {
            notice("§c还没配置 API Key：按 K 打开设置，把 Key 填进去");
            return;
        }
        AiService.chat(clean)
                .thenAccept(reply -> Minecraft.getInstance().execute(() -> handleReply(reply)))
                .exceptionally(err -> {
                    Minecraft.getInstance().execute(() -> notice("§c请求失败：" + err.getMessage()));
                    return null;
                });
    }

    private static void handleReply(String rawReply) {
        JsonObject obj = parseJsonLoose(rawReply);
        if (obj == null) {
            say(stripFences(rawReply).trim());
            return;
        }

        String reply = obj.has("reply") ? obj.get("reply").getAsString().trim() : "";
        String command = obj.has("command") ? obj.get("command").getAsString().trim() : "";

        if (!reply.isEmpty()) {
            say(reply);
        }

        if (command.isEmpty()) {
            return;
        }
        while (command.startsWith("/")) {
            command = command.substring(1);
        }

        AiConfig cfg = AiConfig.get();
        if (!cfg.isAllowed(command)) {
            notice("§c当前权限等级不允许执行：/" + command);
            return;
        }

        if (cfg.requireConfirm) {
            pendingCommand = command;
            notice("§7要执行：§e/" + command + " §7——输 y 确认，n 取消");
        } else {
            execute(command);
        }
    }

    private static void execute(String command) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) {
            notice("§c不在游戏里，没法执行");
            return;
        }
        mc.player.connection.sendCommand(command);
        notice("§a已执行：§e/" + command);
    }

    /** 助手说话：本地一定显示；开了广播再把这句转给其他玩家。 */
    private static void say(String text) {
        AiConfig cfg = AiConfig.get();
        String name = cfg.assistantName == null || cfg.assistantName.isBlank() ? "xiaoyue" : cfg.assistantName;
        String line = (cfg.showName ? "<" + name + "> " : "") + text;

        send(line);

        if (!"tellraw".equalsIgnoreCase(cfg.broadcast)) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) {
            return;
        }
        String me = mc.player.getGameProfile().getName();
        String json = "{\"text\":" + AiConfig.gson().toJson(line) + "}";
        // 除了自己，其他玩家都能看到这一行（需要 OP 权限）
        mc.player.connection.sendCommand("tellraw @a[name=!" + me + "] " + json);
    }

    /** 系统提示（报错、执行结果之类）：不带名字。 */
    private static void notice(String text) {
        send(text);
    }

    /** 模仿原版聊天：<玩家名> 说的话 */
    private static String vanillaEcho(String text) {
        Minecraft mc = Minecraft.getInstance();
        String name = mc.player != null ? mc.player.getGameProfile().getName() : "你";
        return "<" + name + "> " + text;
    }

    private static void send(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal(text), false);
        }
    }

    /** 给服务端逻辑复用的宽松解析。 */
    static JsonObject parseLoose(String rawReply) {
        return parseJsonLoose(rawReply);
    }

    /** 宽松解析：从一堆文字里把第一个 {…} 抠出来解析，失败返回 null。 */
    private static JsonObject parseJsonLoose(String rawReply) {
        String text = stripFences(rawReply == null ? "" : rawReply).trim();
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start < 0 || end <= start) {
            return null;
        }
        try {
            return JsonParser.parseString(text.substring(start, end + 1)).getAsJsonObject();
        } catch (Exception e) {
            return null;
        }
    }

    private static String stripFences(String text) {
        String t = text.trim();
        if (t.startsWith("```")) {
            t = t.replaceFirst("^```[a-zA-Z]*\\s*", "");
            if (t.endsWith("```")) {
                t = t.substring(0, t.length() - 3);
            }
        }
        return t.trim();
    }

    private static String shorten(String text) {
        String t = text == null ? "" : text.replace('\n', ' ');
        return t.length() > 120 ? t.substring(0, 120) + "…" : t;
    }
}
