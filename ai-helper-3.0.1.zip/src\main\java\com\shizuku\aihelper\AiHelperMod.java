package com.shizuku.aihelper;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.logging.LogUtils;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;

/**
 * 入口。
 * - 直接聊天：聊天框直接说话
 * - 关闭直接聊天后：/<助手名字> 你的话
 * - 按 K 打开设置
 */
@Mod(AiHelperMod.MODID)
public final class AiHelperMod {
    public static final String MODID = "aihelper";
    public static final Logger LOGGER = LogUtils.getLogger();

    /** 默认 K 键打开设置，可以在“按键设置”里改 */
    public static final KeyMapping OPEN_CONFIG = new KeyMapping(
            "key.aihelper.config",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "key.categories.xiaoyuehelper");

    public AiHelperMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        // 实体注册（两边都要）
        ModEntities.ENTITY_TYPES.register(modBus);
        modBus.addListener(ModEntities::onAttributeCreation);

        // 背包界面注册
        ModMenus.MENUS.register(modBus);

        // 右键小月打开背包
        MinecraftForge.EVENT_BUS.addListener(AiHelperMod::onOpenBag);

        // 服务端监听：装了这个 mod 的一方（房主/服务器）负责应答，其他人不需要装
        MinecraftForge.EVENT_BUS.addListener(ServerChatHandler::onServerChat);

        if (FMLEnvironment.dist == Dist.CLIENT) {
            modBus.addListener(AiHelperMod::registerKeys);
            MinecraftForge.EVENT_BUS.addListener(AiHelperMod::onChat);
            MinecraftForge.EVENT_BUS.addListener(AiHelperMod::onKeyInput);
            MinecraftForge.EVENT_BUS.addListener(AiHelperMod::onRegisterClientCommands);
            LOGGER.info("AI Helper loaded: 聊天里提到小月即可，按 K 打开设置");
        }
    }

    private static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_CONFIG);
    }

    /** 右键小月 → 打开她的背包/装备界面。 */
    private static void onOpenBag(net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof XiaoyueEntity entity)) {
            return;
        }
        if (event.getSide() != net.minecraft.world.level.LogicalSide.SERVER) {
            return;
        }
        if (!(event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player)) {
            return;
        }
        net.minecraftforge.network.NetworkHooks.openScreen(player,
                new net.minecraft.world.SimpleMenuProvider(
                        (id, inv, p) -> new XiaoyueBagMenu(id, inv, entity.getId()),
                        net.minecraft.network.chat.Component.literal("小月的背包")),
                buf -> buf.writeInt(entity.getId()));
        event.setCanceled(true);
    }

    private static void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        while (OPEN_CONFIG.consumeClick()) {
            if (mc.screen == null) {
                mc.setScreen(new ConfigScreen(null));
            }
        }
    }

    private static void onChat(ClientChatEvent event) {
        ChatHandler.onChat(event);
    }

    /** 注册客户端命令：/<助手名字> 你的话 */
    private static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        String name = AiConfig.get().assistantName;
        if (name == null || name.isBlank()) {
            name = "xiaoyue";
        }
        name = name.trim().toLowerCase().replaceAll("[^a-z0-9_]", "");
        if (name.isEmpty()) {
            name = "xiaoyue";
        }
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal(name)
                .then(Commands.argument("message", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            ChatHandler.ask(StringArgumentType.getString(ctx, "message"));
                            return 1;
                        })));
    }
}
