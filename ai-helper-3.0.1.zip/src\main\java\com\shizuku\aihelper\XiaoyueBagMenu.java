package com.shizuku.aihelper;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * 小月的背包界面：27 格背包 + 装备栏（主手/头盔/胸甲/护腿/靴子）+ 玩家背包。
 */
public class XiaoyueBagMenu extends AbstractContainerMenu {
    public static final int BAG_SIZE = 27;
    private static final int BAG_ROWS = 3;

    private final Container bag;
    private final XiaoyueEntity entity;

    /** 网络工厂 */
    public static XiaoyueBagMenu fromNetwork(int id, Inventory inv, FriendlyByteBuf data) {
        return new XiaoyueBagMenu(id, inv, data.readInt());
    }

    public XiaoyueBagMenu(int id, Inventory playerInv, int entityId) {
        super(ModMenus.BAG.get(), id);
        Player player = playerInv.player;
        this.entity = player.level().getEntity(entityId) instanceof XiaoyueEntity x ? x : null;

        if (this.entity != null && !player.level().isClientSide) {
            this.bag = new SimpleContainer(BAG_SIZE);
            for (int i = 0; i < BAG_SIZE; i++) {
                this.bag.setItem(i, this.entity.getBag().get(i).copy());
            }
        } else {
            this.bag = new SimpleContainer(BAG_SIZE);
        }

        // 背包 3x9
        for (int row = 0; row < BAG_ROWS; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(this.bag, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }

        // 装备栏
        if (this.entity != null) {
            this.addSlot(new EquipSlot(this.entity, EquipmentSlot.MAINHAND, 8, 84));
            this.addSlot(new EquipSlot(this.entity, EquipmentSlot.HEAD, 62, 84));
            this.addSlot(new EquipSlot(this.entity, EquipmentSlot.CHEST, 80, 84));
            this.addSlot(new EquipSlot(this.entity, EquipmentSlot.LEGS, 98, 84));
            this.addSlot(new EquipSlot(this.entity, EquipmentSlot.FEET, 116, 84));
        }

        // 玩家背包
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 112 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInv, col, 8 + col * 18, 170));
        }
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (this.entity != null && !player.level().isClientSide) {
            for (int i = 0; i < BAG_SIZE; i++) {
                this.entity.getBag().set(i, this.bag.getItem(i).copy());
            }
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return result;
        }
        ItemStack stack = slot.getItem();
        result = stack.copy();

        int bagEnd = BAG_SIZE;
        int equipEnd = bagEnd + (this.entity != null ? 5 : 0);
        int playerEnd = equipEnd + 36;

        if (index < bagEnd) {
            if (!this.moveItemStackTo(stack, equipEnd, playerEnd, true)) {
                return ItemStack.EMPTY;
            }
        } else if (index < equipEnd) {
            if (!this.moveItemStackTo(stack, 0, bagEnd, false)
                    && !this.moveItemStackTo(stack, equipEnd, playerEnd, false)) {
                return ItemStack.EMPTY;
            }
        } else {
            // 玩家背包 → 优先装备栏，再背包
            int target = Mob.getEquipmentSlotForItem(stack) != null && this.entity != null
                    ? equipEnd : bagEnd;
            if (!this.moveItemStackTo(stack, bagEnd, target, false)) {
                if (!this.moveItemStackTo(stack, 0, bagEnd, false)) {
                    return ItemStack.EMPTY;
                }
            }
        }

        if (stack.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.entity == null || this.entity.isAlive();
    }

    /** 直接读写实体装备的槽位。 */
    private static class EquipSlot extends Slot {
        private final XiaoyueEntity entity;
        private final EquipmentSlot equipmentSlot;

        EquipSlot(XiaoyueEntity entity, EquipmentSlot equipmentSlot, int x, int y) {
            super(new SimpleContainer(1), 0, x, y);
            this.entity = entity;
            this.equipmentSlot = equipmentSlot;
        }

        @Override
        public ItemStack getItem() {
            return this.entity.getItemBySlot(this.equipmentSlot);
        }

        @Override
        public void set(ItemStack stack) {
            this.entity.setItemSlot(this.equipmentSlot, stack);
        }

        @Override
        public void setChanged() {
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return Mob.getEquipmentSlotForItem(stack) == this.equipmentSlot;
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }
}
