package com.shizuku.aihelper;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 小月的背包界面（不依赖贴图，用色块画）。 */
public class XiaoyueBagScreen extends AbstractContainerScreen<XiaoyueBagMenu> {
    public XiaoyueBagScreen(XiaoyueBagMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 196;
        this.inventoryLabelY = 100;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos;
        int y = this.topPos;

        // 半透明底板
        graphics.fill(x, y, x + this.imageWidth, y + this.imageHeight, 0xC0101010);
        // 边框
        graphics.fill(x, y, x + this.imageWidth, y + 1, 0xFF9A9A9A);
        graphics.fill(x, y + this.imageHeight - 1, x + this.imageWidth, y + this.imageHeight, 0xFF9A9A9A);
        graphics.fill(x, y, x + 1, y + this.imageHeight, 0xFF9A9A9A);
        graphics.fill(x + this.imageWidth - 1, y, x + this.imageWidth, y + this.imageHeight, 0xFF9A9A9A);

        // 背包区 / 装备区 / 玩家区 分隔线
        graphics.fill(x + 6, y + 76, x + this.imageWidth - 6, y + 77, 0xFF6A6A6A);
        graphics.fill(x + 6, y + 104, x + this.imageWidth - 6, y + 105, 0xFF6A6A6A);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        this.renderTooltip(graphics, mouseX, mouseY);
    }
}
