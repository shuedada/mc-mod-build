package com.shizuku.aihelper;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * /aiconfig 打开的游戏内设置界面。
 * 所有选项点一下就能改，改完点“保存”写回 config/aihelper.json。
 */
public class ConfigScreen extends Screen {
    private final Screen parent;

    private EditBox apiKeyField;
    private EditBox nameField;
    private EditBox personaField;

    private Button levelButton;
    private Button broadcastButton;
    private Button chatModeButton;
    private Button forwardButton;
    private Button confirmButton;
    private Button nameToggleButton;

    private int level;
    private String broadcast;
    private boolean chatMode;
    private boolean forwardChat;
    private boolean requireConfirm;
    private boolean showName;

    public ConfigScreen(Screen parent) {
        super(Component.literal("AI 助手设置"));
        this.parent = parent;
        AiConfig cfg = AiConfig.get();
        this.level = Math.max(1, Math.min(3, cfg.permissionLevel <= 0 ? 2 : cfg.permissionLevel));
        this.broadcast = cfg.broadcast == null ? "off" : cfg.broadcast;
        this.chatMode = cfg.chatMode;
        this.forwardChat = cfg.forwardChat;
        this.requireConfirm = cfg.requireConfirm;
        this.showName = cfg.showName;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int fieldWidth = Math.min(320, this.width - 40);
        int left = cx - fieldWidth / 2;
        int y = 46;

        this.apiKeyField = new EditBox(this.font, left, y, fieldWidth, 20, Component.literal("API Key"));
        this.apiKeyField.setMaxLength(200);
        this.apiKeyField.setValue(AiConfig.get().apiKey == null ? "" : AiConfig.get().apiKey);
        this.addRenderableWidget(this.apiKeyField);
        y += 36;

        this.nameField = new EditBox(this.font, left, y, fieldWidth, 20, Component.literal("名字"));
        this.nameField.setMaxLength(32);
        this.nameField.setValue(AiConfig.get().assistantName == null ? "" : AiConfig.get().assistantName);
        this.nameField.setEditable(this.isHost());
        this.addRenderableWidget(this.nameField);
        y += 36;

        this.personaField = new EditBox(this.font, left, y, fieldWidth, 20, Component.literal("人设"));
        this.personaField.setMaxLength(300);
        this.personaField.setEditable(this.isHost());
        this.personaField.setValue(AiConfig.get().persona == null ? "" : AiConfig.get().persona);
        this.addRenderableWidget(this.personaField);
        y += 40;

        int bw = (fieldWidth - 10) / 2;

        this.levelButton = Button.builder(Component.literal(levelLabel()), b -> {
            this.level = this.level >= 3 ? 1 : this.level + 1;
            b.setMessage(Component.literal(levelLabel()));
        }).bounds(left, y, bw, 20).build();
        this.addRenderableWidget(this.levelButton);

        this.broadcastButton = Button.builder(Component.literal(broadcastLabel()), b -> {
            this.broadcast = "tellraw".equalsIgnoreCase(this.broadcast) ? "off" : "tellraw";
            b.setMessage(Component.literal(broadcastLabel()));
        }).bounds(left + bw + 10, y, bw, 20).build();
        this.addRenderableWidget(this.broadcastButton);
        y += 26;

        this.chatModeButton = Button.builder(Component.literal(toggleLabel("直接聊天", this.chatMode)), b -> {
            this.chatMode = !this.chatMode;
            b.setMessage(Component.literal(toggleLabel("直接聊天", this.chatMode)));
        }).bounds(left, y, bw, 20).build();
        this.addRenderableWidget(this.chatModeButton);

        this.forwardButton = Button.builder(Component.literal(toggleLabel("聊天发给服务器", this.forwardChat)), b -> {
            this.forwardChat = !this.forwardChat;
            b.setMessage(Component.literal(toggleLabel("聊天发给服务器", this.forwardChat)));
        }).bounds(left + bw + 10, y, bw, 20).build();
        this.addRenderableWidget(this.forwardButton);
        y += 26;

        this.confirmButton = Button.builder(Component.literal(toggleLabel("执行前确认", this.requireConfirm)), b -> {
            this.requireConfirm = !this.requireConfirm;
            b.setMessage(Component.literal(toggleLabel("执行前确认", this.requireConfirm)));
        }).bounds(left, y, bw, 20).build();
        this.addRenderableWidget(this.confirmButton);

        this.nameToggleButton = Button.builder(Component.literal(toggleLabel("显示名字", this.showName)), b -> {
            this.showName = !this.showName;
            b.setMessage(Component.literal(toggleLabel("显示名字", this.showName)));
        }).bounds(left + bw + 10, y, bw, 20).build();
        this.addRenderableWidget(this.nameToggleButton);
        y += 34;

        this.addRenderableWidget(Button.builder(Component.literal("保存"), b -> saveAndClose())
                .bounds(cx - bw - 5, y, bw, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("取消"), b -> onClose())
                .bounds(cx + 5, y, bw, 20).build());
    }

    private String levelLabel() {
        return switch (this.level) {
            case 1 -> "权限：安全（1）";
            case 3 -> "权限：全开（3）";
            default -> "权限：常规（2）";
        };
    }

    private String broadcastLabel() {
        return "tellraw".equalsIgnoreCase(this.broadcast) ? "广播：开（需 OP）" : "广播：关";
    }

    private static String toggleLabel(String name, boolean on) {
        return name + (on ? "：开" : "：关");
    }

    /**
     * 只有拥有 OP 权限的人才能改名字和人设（不再看是不是房主）。
     * 客户端拿不到精确的 OP 等级，这里用权限等级 ≥ 2 做近似判断。
     */
    private boolean isHost() {
        if (this.minecraft == null || this.minecraft.player == null) {
            return true;
        }
        return this.minecraft.player.hasPermissions(2);
    }

    private void saveAndClose() {
        AiConfig cfg = AiConfig.get();
        cfg.apiKey = this.apiKeyField.getValue().trim();
        cfg.assistantName = this.nameField.getValue().trim();
        if (!this.personaField.getValue().isBlank()) {
            cfg.persona = this.personaField.getValue().trim();
        }
        cfg.permissionLevel = this.level;
        cfg.broadcast = this.broadcast;
        cfg.chatMode = this.chatMode;
        cfg.forwardChat = this.forwardChat;
        cfg.requireConfirm = this.requireConfirm;
        cfg.showName = this.showName;
        AiConfig.save();
        onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int cx = this.width / 2;
        graphics.drawCenteredString(this.font, this.title, cx, 20, 0xFFFFFF);

        int fieldWidth = Math.min(320, this.width - 40);
        int left = cx - fieldWidth / 2;
        graphics.drawString(this.font, "API Key（必填）", left, 34, 0xA0A0A0, false);
        graphics.drawString(this.font, this.isHost() ? "助手名字" : "助手名字（由房主控制）", left, 70,
                this.isHost() ? 0xA0A0A0 : 0x707070, false);
        graphics.drawString(this.font, this.isHost() ? "人设（一句话）" : "人设（由房主控制）", left, 106,
                this.isHost() ? 0xA0A0A0 : 0x707070, false);

        super.render(graphics, mouseX, mouseY, partialTick);

        graphics.drawCenteredString(this.font,
                Component.literal("按 K 打开这个界面 · 聊天框直接说话就能对话"),
                cx, this.height - 28, 0x808080);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parent);
    }
}
