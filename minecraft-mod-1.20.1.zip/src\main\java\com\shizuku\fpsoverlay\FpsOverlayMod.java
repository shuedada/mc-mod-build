package com.shizuku.fpsoverlay;

import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

/**
 * 入口：只在客户端挂载 HUD。
 */
@Mod(FpsOverlayMod.MODID)
public final class FpsOverlayMod {
    public static final String MODID = "fps_overlay";
    private static final Logger LOGGER = LogUtils.getLogger();

    public FpsOverlayMod() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.register(FMLJavaModLoadingContext.get().getModEventBus());
        }
        LOGGER.info("FPS Overlay loaded");
    }
}
