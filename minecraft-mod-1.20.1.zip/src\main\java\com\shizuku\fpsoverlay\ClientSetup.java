package com.shizuku.fpsoverlay;

import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.IEventBus;

/** 客户端注册：只在这里碰客户端类，服务端不会加载它。 */
final class ClientSetup {
    private ClientSetup() {
    }

    static void register(IEventBus modBus) {
        modBus.addListener(ClientSetup::onRegisterOverlays);
    }

    private static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("fps_counter", new FpsOverlay());
    }
}
