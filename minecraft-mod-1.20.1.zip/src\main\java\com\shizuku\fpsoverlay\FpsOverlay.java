package com.shizuku.fpsoverlay;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * 右上角常驻的 FPS 数字。
 * 60 以上绿色、30-59 黄色、30 以下红色；带半透明底色，任何亮度下都看得清。
 */
public class FpsOverlay implements IGuiOverlay {
    private static final int BACKGROUND = 0x90000000;
    private static final int MARGIN = 6;
    private static final int PADDING_X = 4;
    private static final int PADDING_Y = 3;

    @Override
    public void render(ForgeGui gui, GuiGraphics graphics, float partialTick, int screenWidth, int screenHeight) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null) {
            return;
        }

        int fps = mc.getFps();
        String text = fps + " FPS";
        int color = fps >= 60 ? 0xFF55FF55 : fps >= 30 ? 0xFFFFFF55 : 0xFFFF5555;

        int textWidth = mc.font.width(text);
        int textHeight = mc.font.lineHeight;
        int x = screenWidth - textWidth - MARGIN;
        int y = MARGIN;

        graphics.fill(
                x - PADDING_X,
                y - PADDING_Y,
                x + textWidth + PADDING_X,
                y + textHeight + PADDING_Y,
                BACKGROUND);
        graphics.drawString(mc.font, text, x, y, color, true);
    }
}
