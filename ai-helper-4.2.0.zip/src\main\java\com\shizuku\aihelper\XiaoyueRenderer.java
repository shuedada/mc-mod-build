package com.shizuku.aihelper;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * 小月的渲染：细手臂玩家模型 + 手持物 + 护甲。
 * 坐姿由 XiaoyueModel 处理，睡姿由原版 LivingEntityRenderer 处理。
 */
public class XiaoyueRenderer extends LivingEntityRenderer<XiaoyueEntity, XiaoyueModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AiHelperMod.MODID, "textures/entity/xiaoyue.png");

    public XiaoyueRenderer(EntityRendererProvider.Context context) {
        super(context, new XiaoyueModel(context.bakeLayer(ModelLayers.PLAYER_SLIM), true), 0.5F);

        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(XiaoyueEntity entity) {
        return TEXTURE;
    }
}
