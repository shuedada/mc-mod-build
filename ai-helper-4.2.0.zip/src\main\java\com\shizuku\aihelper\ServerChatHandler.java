package com.shizuku.aihelper;

import com.google.gson.JsonObject;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 服务端逻辑：谁在聊天里提到「小月」，就由服务器去问 AI，
 * 然后把回复广播给所有人，必要时以服务器权限执行命令。
 *
 * 房主装了这个 mod，其他人什么都不用装。
 */
public final class ServerChatHandler {
    /** 每个玩家待确认的命令 */
    private static final Map<UUID, String> PENDING = new ConcurrentHashMap<>();
    /** 每个玩家上一次提问的时间 */
    private static final Map<UUID, Long> LAST_CALL = new ConcurrentHashMap<>();
    /** 不同玩家的消息排队 */
    private static final java.util.Deque<Runnable> QUEUE = new java.util.ArrayDeque<>();
    private static boolean busy = false;
    /** 同一个人的两次提问最小间隔，防止刷屏烧钱 */
    private static final long MIN_INTERVAL_MS = 1500L;
    private static final int MAX_QUEUE = 3;

    private ServerChatHandler() {
    }

    @SubscribeEvent
    public static void onServerChat(ServerChatEvent event) {
        AiConfig cfg = AiConfig.get();
        MinecraftServer server = event.getPlayer().getServer();
        String message = event.getMessage().getString();
        if (message == null || message.isBlank() || server == null) {
            return;
        }

        ServerPlayer player = event.getPlayer();

        // 1) 有待确认的命令：这个玩家说 y / 好 就执行
        String pending = PENDING.get(player.getUUID());
        if (pending != null) {
            String key = message.trim().toLowerCase(Locale.ROOT);
            if (key.equals("y") || key.equals("yes") || key.equals("是") || key.equals("好")) {
                PENDING.remove(player.getUUID());
                execute(player, pending);
                return;
            }
            if (key.equals("n") || key.equals("no") || key.equals("不") || key.equals("取消")) {
                PENDING.remove(player.getUUID());
                broadcast(server, "§7好，那就不做了");
                return;
            }
        }

        // 2) 需要叫名字时，没提到名字就不理；关掉之后就“句句都算”
        if (cfg.requireName && !mentionsName(message, cfg)) {
            return;
        }

        // 所有指令都交给 AI 判断（模型返回 action）
        String text = cfg.requireName ? stripName(message, cfg) : message.trim();
        XiaoyueEntity entity = ensureEntity(server, player);

        if (!cfg.ready()) {
            broadcast(server, "§c还没填 API Key：房主按 K 打开设置，或者改 config/aihelper.json");
            return;
        }

        // 同一个人 1.5 秒内的消息直接丢弃；不同的人排队
        long now = System.currentTimeMillis();
        Long last = LAST_CALL.get(player.getUUID());
        if (last != null && now - last < MIN_INTERVAL_MS) {
            return;
        }
        LAST_CALL.put(player.getUUID(), now);

        String asker = player.getGameProfile().getName();
        String status = entity != null ? "\n[我的状态] " + entity.statusLine() + entity.worldSnapshot() : "";
        ask(server, player, "[" + asker + "] " + text + status);
    }

    /** 右键界面发来的话：不用经过聊天框，直接走服务端逻辑。 */
    public static void askFromGui(MinecraftServer server, UUID playerId, String rawText) {
        ServerPlayer player = server.getPlayerList().getPlayer(playerId);
        if (player == null) {
            return;
        }
        AiConfig cfg = AiConfig.get();
        String text = rawText == null ? "" : rawText.trim();
        if (text.isEmpty()) {
            return;
        }

        XiaoyueEntity entity = ensureEntity(server, player);

        if (!cfg.ready()) {
            broadcast(server, "§c还没填 API Key：按 K 打开设置填一下");
            return;
        }

        long now = System.currentTimeMillis();
        Long last = LAST_CALL.get(playerId);
        if (last != null && now - last < MIN_INTERVAL_MS) {
            return;
        }
        LAST_CALL.put(playerId, now);

        String asker = player.getGameProfile().getName();
        String status = entity != null ? "\n[我的状态] " + entity.statusLine() + entity.worldSnapshot() : "";
        ask(server, player, "[" + asker + "] " + text + status);
    }

    /** 当前有人在问就排队，空闲就直接发。 */
    private static void ask(MinecraftServer server, ServerPlayer player, String payload) {
        Runnable task = () -> AiService.chat(payload)
                .thenAccept(reply -> server.execute(() -> handleReply(server, player, reply)))
                .exceptionally(err -> {
                    server.execute(() -> broadcast(server, "§c请求失败：" + err.getMessage()));
                    return null;
                })
                .whenComplete((v, e) -> askFinished());

        synchronized (QUEUE) {
            if (busy) {
                if (QUEUE.size() < MAX_QUEUE) {
                    QUEUE.addLast(task);
                }
                return;
            }
            busy = true;
        }
        task.run();
    }

    private static void askFinished() {
        Runnable next;
        synchronized (QUEUE) {
            next = QUEUE.pollFirst();
            if (next == null) {
                busy = false;
                return;
            }
        }
        next.run();
    }

    /** 在玩家附近找小月，没有就生成一个。 */
    private static XiaoyueEntity ensureEntity(MinecraftServer server, ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level)) {
            return null;
        }
        List<XiaoyueEntity> found = level.getEntitiesOfClass(XiaoyueEntity.class, player.getBoundingBox().inflate(64.0D));
        if (!found.isEmpty()) {
            return found.get(0);
        }
        EntityType<XiaoyueEntity> type = ModEntities.XIAOYUE.get();
        XiaoyueEntity entity = type.create(level);
        if (entity == null) {
            return null;
        }
        entity.moveTo(player.getX() + 1.0D, player.getY(), player.getZ() + 1.0D, player.getYRot(), 0.0F);
        entity.setOwner(player);

        // 出现时什么都不带，空手

        level.addFreshEntity(entity);
        AiNarrator.note(AiConfig.get().assistantName + " 出现在 " + player.getGameProfile().getName() + " 身边");
        broadcast(server, "§7小月出现了");
        return entity;
    }

    /** AI 判断出的动作。 */
    private static void runAction(MinecraftServer server, ServerPlayer player, String action) {
        XiaoyueEntity entity = ensureEntity(server, player);
        if (entity == null) {
            return;
        }
        switch (action.toLowerCase(Locale.ROOT)) {
            case "come" -> entity.comeTo(player);
            case "stay" -> {
                entity.setFollowing(false);
                entity.getNavigation().stop();
            }
            case "follow" -> {
                entity.standUp();
                entity.setFollowing(true);
            }
            case "sit" -> entity.sit();
            case "stand" -> entity.standUp();
            case "sleep" -> trySleep(server, entity, player);
            case "give_equipment" -> entity.giveEquipmentTo(player);
            case "forget" -> {
                AiService.resetHistory();
                AiNarrator.clear();
            }
            default -> {
                return;
            }
        }
        AiHelperMod.LOGGER.info("[action] 执行动作：{}", action);
    }

    /** 睡觉：白天不睡，没床就说没床。 */
    private static void trySleep(MinecraftServer server, XiaoyueEntity entity, ServerPlayer player) {
        long t = entity.level().getDayTime() % 24000L;
        boolean night = t >= 13000L && t <= 23000L;
        if (!night) {
            AiNarrator.note("主人让你睡觉，但现在还是白天");
            say(server, "大白天的睡什么睡");
            return;
        }
        var bed = entity.findNearbyBed(16);
        if (bed == null) {
            AiNarrator.note("主人让你睡觉，但你附近没有床");
            say(server, "这附近没有床啊");
        } else {
            entity.startSleeping(bed);
            AiNarrator.note("你躺到床上睡觉了");
        }
    }

    private static void execute(ServerPlayer player, String command) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        try {
            // 命令来源绑定到这个玩家，@s 才有意义
            CommandSourceStack source = player.createCommandSourceStack()
                    .withPermission(4)
                    .withSuppressedOutput();
            server.getCommands().performPrefixedCommand(source, command);
            broadcast(server, "§7（已执行 /" + command + "）");
        } catch (Exception e) {
            broadcast(server, "§c执行失败：" + e.getMessage());
        }
    }

    /** 主动开口时的回复：默认只说话；开了 proactiveAllowCommand 才会顺手执行命令。 */
    public static void proactiveReply(MinecraftServer server, ServerPlayer owner, String raw) {
        JsonObject obj = ChatHandler.parseLoose(raw);
        String text = obj != null && obj.has("reply") ? obj.get("reply").getAsString().trim() : raw;
        if (text != null && !text.isBlank()) {
            say(server, text.trim());
        }

        AiConfig cfg = AiConfig.get();
        if (!cfg.proactiveAllowCommand || obj == null || !obj.has("command") || owner == null) {
            return;
        }
        String command = obj.get("command").getAsString().trim();
        while (command.startsWith("/")) {
            command = command.substring(1);
        }
        if (!command.isEmpty() && cfg.isAllowed(command)) {
            execute(owner, command);
        }
    }

    static void say(MinecraftServer server, String text) {
        AiConfig cfg = AiConfig.get();
        String name = cfg.assistantName == null || cfg.assistantName.isBlank() ? "xiaoyue" : cfg.assistantName;
        String line = (cfg.showName ? "<" + name + "> " : "") + text;
        broadcast(server, line);
    }

    private static void broadcast(MinecraftServer server, String text) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(text), false);
    }

    /** 这些词出现就算在叫它 */
    private static boolean mentionsName(String message, AiConfig cfg) {
        String lower = message.toLowerCase(Locale.ROOT);
        if (lower.contains("小月") || lower.contains("xiaoyue")) {
            return true;
        }
        String name = cfg.assistantName;
        return name != null && !name.isBlank() && lower.contains(name.toLowerCase(Locale.ROOT));
    }

    /** 把称呼去掉，剩下的话再交给模型 */
    private static String stripName(String message, AiConfig cfg) {
        String text = message;
        for (String token : new String[]{"小月", "xiaoyue", cfg.assistantName}) {
            if (token == null || token.isBlank()) {
                continue;
            }
            text = text.replace(token, " ");
            text = text.replace(token.toUpperCase(Locale.ROOT), " ");
        }
        text = text.replaceAll("\\s{2,}", " ").trim();
        return text.isEmpty() ? message : text;
    }
}
