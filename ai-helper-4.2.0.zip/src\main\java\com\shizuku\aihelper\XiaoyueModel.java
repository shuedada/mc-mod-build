package com.shizuku.aihelper;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;

/**
 * 小月的模型：直接复用原版的潜行（crouch）姿态，不自造动作。
 * 坐下 = 原版蹲下。
 */
public class XiaoyueModel extends PlayerModel<XiaoyueEntity> {
    public XiaoyueModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    @Override
    public void setupAnim(XiaoyueEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // 交给原版：crouching=true 就是标准潜行姿势
        this.crouching = entity.getPose() == net.minecraft.world.entity.Pose.CROUCHING;
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
    }
}
