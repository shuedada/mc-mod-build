package com.shizuku.aihelper;

import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 容器菜单注册。 */
public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, AiHelperMod.MODID);

    public static final RegistryObject<MenuType<XiaoyueBagMenu>> BAG =
            MENUS.register("bag", () -> IForgeMenuType.create(XiaoyueBagMenu::fromNetwork));

    private ModMenus() {
    }
}
