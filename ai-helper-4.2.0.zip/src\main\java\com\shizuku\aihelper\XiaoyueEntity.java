package com.shizuku.aihelper;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * 小月的实体：玩家大小、会看向你、可以跟着你走或者站在原地。
 */
public class XiaoyueEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> DATA_FOLLOWING =
            SynchedEntityData.defineId(XiaoyueEntity.class, EntityDataSerializers.BOOLEAN);

    @Nullable
    private UUID ownerUuid;
    private int idleTicks;
    private String lastEquipmentSig = "";
    private boolean selfEquip;
    private int lastOwnerHurtTime;
    private long lastFarNoteAt;
    private boolean resting;
    private int standStillTicks;
    private boolean chasing;
    private boolean closeWarned;
    /** 自主行为状态：0 无 / 1 逃跑 / 2 捡东西 */
    private int autoState;
    private boolean lootStarted;
    private long lastTorchAt;
    @Nullable
    private net.minecraft.core.BlockPos sleptAt;
    /** 27 格背包 */
    private final net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> bag =
            net.minecraft.core.NonNullList.withSize(27, net.minecraft.world.item.ItemStack.EMPTY);

    public net.minecraft.core.NonNullList<net.minecraft.world.item.ItemStack> getBag() {
        return this.bag;
    }

    public XiaoyueEntity(EntityType<? extends XiaoyueEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setCanPickUpLoot(true);
        this.xpReward = 0;

        // 头顶只显示名字，不要那一长串翻译键
        String display = AiConfig.get().assistantName;
        if (display == null || display.isBlank()) {
            display = "xiaoyue";
        }
        this.setCustomName(net.minecraft.network.chat.Component.literal(display));
        this.setCustomNameVisible(true);

        // 死亡时身上装备全部掉落
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            this.setDropChance(slot, 1.0F);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_FOLLOWING, Boolean.TRUE);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F, 1.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.5D));
    }

    public boolean isFollowing() {
        return this.entityData.get(DATA_FOLLOWING);
    }

    public void setFollowing(boolean value) {
        this.entityData.set(DATA_FOLLOWING, value);
    }

    public void setOwner(@Nullable Player player) {
        this.ownerUuid = player == null ? null : player.getUUID();
    }

    /** 坐下：停下不动，用蹲姿表现。 */
    public void sit() {
        this.resting = true;
        this.standStillTicks = 0;
        this.getNavigation().stop();
        this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
        this.setFollowing(false);
        this.setPose(net.minecraft.world.entity.Pose.CROUCHING);
    }

    /** 站起来。 */
    public void standUp() {
        this.resting = false;
        this.standStillTicks = 0;
        this.sleptAt = null;
        if (this.getPose() == net.minecraft.world.entity.Pose.SLEEPING) {
            this.stopSleeping();
        }
        this.setPose(net.minecraft.world.entity.Pose.STANDING);
    }

    public boolean isResting() {
        return this.resting;
    }

    /** 上床躺着。 */
    public void startSleeping(net.minecraft.core.BlockPos bedPos) {
        this.resting = true;
        this.standStillTicks = 0;
        this.getNavigation().stop();

        // 床分头尾两部分：必须先找到“枕头那半”，否则人会躺在脚那头，半截身子悬在外面
        net.minecraft.core.BlockPos headPos = bedPos;
        var state = this.level().getBlockState(bedPos);
        if (state.getBlock() instanceof net.minecraft.world.level.block.BedBlock
                && state.getValue(net.minecraft.world.level.block.BedBlock.PART)
                == net.minecraft.world.level.block.state.properties.BedPart.FOOT) {
            headPos = bedPos.relative(state.getValue(net.minecraft.world.level.block.BedBlock.FACING));
        }
        this.sleptAt = headPos.immutable();

        // 交给原版：记录床的位置、摆成躺姿，方向由 LivingEntityRenderer 按床朝向转
        super.startSleeping(headPos);

        // 从枕头那半往脚的方向挪 0.35 格，让身体整个人压在床垫上
        var headState = this.level().getBlockState(headPos);
        net.minecraft.core.Direction facing = headState.getBlock() instanceof net.minecraft.world.level.block.BedBlock
                ? headState.getValue(net.minecraft.world.level.block.BedBlock.FACING)
                : net.minecraft.core.Direction.NORTH;
        double px = headPos.getX() + 0.5D - facing.getStepX() * 0.5D;
        double pz = headPos.getZ() + 0.5D - facing.getStepZ() * 0.5D;
        this.setPos(px, headPos.getY() + 0.5625D, pz);

        this.setFollowing(false);
    }

    /** 正在睡觉（用来判断床还在不在）。 */
    @Nullable
    public net.minecraft.core.BlockPos getSleptAt() {
        return this.sleptAt;
    }

    /** 附近找一张床。 */
    @Nullable
    public net.minecraft.core.BlockPos findNearbyBed(int radius) {
        net.minecraft.core.BlockPos origin = this.blockPosition();
        for (net.minecraft.core.BlockPos pos : net.minecraft.core.BlockPos.betweenClosed(
                origin.offset(-radius, -3, -radius), origin.offset(radius, 3, radius))) {
            if (this.level().getBlockState(pos).getBlock() instanceof net.minecraft.world.level.block.BedBlock) {
                return pos.immutable();
            }
        }
        return null;
    }

    @Nullable
    public Player getOwner() {
        if (this.ownerUuid == null) {
            return null;
        }
        return this.level().getPlayerByUUID(this.ownerUuid);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }

        // 附近没人的时候慢慢“消失”
        int vanishSeconds = AiConfig.get().idleVanishSeconds;
        if (vanishSeconds > 0) {
            boolean someoneNear = !this.level().getEntitiesOfClass(
                    Player.class,
                    this.getBoundingBox().inflate(8.0D),
                    p -> p.isAlive() && !p.isSpectator()).isEmpty();
            if (someoneNear) {
                this.idleTicks = 0;
            } else {
                this.idleTicks++;
                if (this.idleTicks > vanishSeconds * 20) {
                    this.discard();
                    return;
                }
            }
        }

        // 坐着 / 躺着：不许自己乱走
        if (this.resting) {
            this.getNavigation().stop();
            var motion = this.getDeltaMovement();
            this.setDeltaMovement(0.0D, motion.y, 0.0D);

            if (this.sleptAt != null) {
                // 睡觉时头不要乱转
                this.setYHeadRot(this.getYRot());
                this.yHeadRotO = this.getYRot();
                this.yBodyRot = this.getYRot();

                // 床被拆了 → 立刻站起来
                boolean bedGone = !(this.level().getBlockState(this.sleptAt).getBlock()
                        instanceof net.minecraft.world.level.block.BedBlock);
                if (bedGone) {
                    Player ownerNow = this.getOwner();
                    String me = this.myName();
                    this.sleptAt = null;
                    this.standUp();
                    String situation = me + " 睡的床被拆了，只能站起来";
                    AiNarrator.note(situation);
                    ProactiveChat.fireNow(this.getServer(), this.ownerOrNull(), situation);
                }
            }
            return;
        }

        // 自主行为（只在服务端跑）
        if (!this.level().isClientSide && this.tickCount % 20 == 0) {
            this.autonomousTick();
        }

        // 站着不动一会儿就自己坐下
        if (!this.isFollowing() && this.getTarget() == null) {
            if (this.getDeltaMovement().horizontalDistanceSqr() < 0.0004D) {
                this.standStillTicks++;
                int autoSit = AiConfig.get().autoSitSeconds;
                if (autoSit > 0 && this.standStillTicks > autoSit * 20) {
                    this.sit();
                    return;
                }
            } else {
                this.standStillTicks = 0;
            }
        } else {
            this.standStillTicks = 0;
        }

        // 只打“正在打主人”的生物：每 20 tick 扫一次
        Player ownerForCombat = this.getOwner();
        if (ownerForCombat != null && ownerForCombat.isAlive() && this.tickCount % 20 == 0) {
            if (this.autoState != 1 && (this.getTarget() == null || !this.getTarget().isAlive())) {
                Mob attacker = this.level().getEntitiesOfClass(Mob.class,
                                this.getBoundingBox().inflate(16.0D),
                                m -> m != this && m.isAlive() && m.getTarget() == ownerForCombat)
                        .stream().findFirst().orElse(null);
                if (attacker != null) {
                    this.setTarget(attacker);
                    AiNarrator.note(this.myName() + " 出手保护 " + ownerForCombat.getName().getString()
                            + "，目标 " + attacker.getName().getString());
                }
            }
        }

        Player owner = this.getOwner();
        if (owner == null || !owner.isAlive()) {
            return;
        }

        // 旁白：主人挨打 / 装备变化 / 距离太远
        if (owner.hurtTime > 0 && this.lastOwnerHurtTime == 0) {
            net.minecraft.world.entity.LivingEntity attacker = owner.getLastHurtByMob();
            String situation;
            if (attacker != null && attacker != this) {
                String who = attacker.getName().getString();
                net.minecraft.world.item.ItemStack weapon = attacker.getMainHandItem();
                String what = weapon.isEmpty() ? "空手" : weapon.getHoverName().getString();
                situation = who + " 用 " + what + " 打了 " + owner.getName().getString() + " 一下";
            } else {
                situation = owner.getName().getString() + " 受到了伤害";
            }
            AiNarrator.note(situation);
            ProactiveChat.fire(this.getServer(), this.ownerOrNull(), situation);
        }
        this.lastOwnerHurtTime = owner.hurtTime;

        // 装备变化：谁给的、给了什么，都记下来并回一句
        if (this.tickCount % 20 == 0) {
            String sig = this.equipmentSignature();
            if (!sig.equals(this.lastEquipmentSig)) {
                boolean first = this.lastEquipmentSig.isEmpty();
                this.lastEquipmentSig = sig;
                // 刚进世界/刚刷出来那次只记录，不开口（否则一进游戏她就说话）
                if (!first) {
                    String who = owner.getName().getString();
                    String me = this.myName();
                    String desc = this.equipmentDescription();
                    String situation;
                    if (this.selfEquip) {
                        situation = me + " 自己把 " + desc + " 捡起来装备上了";
                    } else if (desc.isEmpty()) {
                        situation = who + " 把 " + me + " 的装备全拿走了";
                    } else {
                        situation = who + " 给 " + me + " 装备了 " + desc;
                    }
                    this.selfEquip = false;
                    AiNarrator.note(situation);
                    ProactiveChat.fireNow(this.getServer(), this.ownerOrNull(), situation);
                }
            }
        }

        // 捡地上的装备：对应格子空着就直接穿上
        if (this.tickCount % 20 == 0) {
            for (net.minecraft.world.entity.item.ItemEntity drop :
                    this.level().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                            this.getBoundingBox().inflate(4.0D))) {
                if (!drop.isAlive()) {
                    continue;
                }
                net.minecraft.world.item.ItemStack stack = drop.getItem();
                net.minecraft.world.entity.EquipmentSlot slot =
                        Mob.getEquipmentSlotForItem(stack);
                if (slot == null || !this.getItemBySlot(slot).isEmpty()) {
                    continue;
                }
                this.selfEquip = true;
                this.setItemSlot(slot, stack.copy());
                this.setDropChance(slot, 1.0F);
                drop.discard();
            }
        }

        double distSq = this.distanceToSqr(owner);
        if (distSq > 576.0D) {
            long nowMs = System.currentTimeMillis();
            if (nowMs - this.lastFarNoteAt > 10_000L) {
                this.lastFarNoteAt = nowMs;
                AiNarrator.note(owner.getName().getString() + " 离 " + this.myName() + " 太远了");
            }
        }

        // 站定时不跟过去
        if (!this.isFollowing()) {
            return;
        }
        if (distSq > 576.0D) {
            if (this.tickCount % 40 == 0) {
                // 只有真的走丢（24 格以上）才传送，平时让她自己走
                this.teleportTo(owner.getX(), owner.getY(), owner.getZ());
                this.setDeltaMovement(0, 0, 0);
            }
        } else if (this.getTarget() == null) {
            // 2 格以内停下，超过 2 格就贴过去；跟丢的时候主动喊一句
            if (distSq > 4.0D) {
                if (distSq > 25.0D && !this.chasing) {
                    this.chasing = true;
                    ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                            owner.getName().getString() + " 走太快了，你追不上");
                }
                if (this.tickCount % 5 == 0) {
                    this.getNavigation().moveTo(owner, 1.25D);
                }
            } else {
                this.chasing = false;
                // 贴脸了就稍微让开一点（1 格以内后退到 2 格左右）
                boolean tooClose = distSq < 1.0D;
                if (tooClose) {
                    if (!this.closeWarned) {
                        this.closeWarned = true;
                        ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                                owner.getName().getString() + " 贴你太近了，你往后退了一步");
                    }
                    if (this.tickCount % 15 == 0) {
                        double dx = this.getX() - owner.getX();
                        double dz = this.getZ() - owner.getZ();
                        double len = Math.sqrt(dx * dx + dz * dz);
                        if (len < 0.05D) {
                            dx = 1.0D;
                            dz = 0.0D;
                            len = 1.0D;
                        }
                        double step = 2.0D / len;
                        this.getNavigation().moveTo(this.getX() + dx * step, this.getY(),
                                this.getZ() + dz * step, 1.0D);
                    }
                } else {
                    this.closeWarned = false;
                    this.getNavigation().stop();
                }
            }
        }
    }

    /** 自己叫什么（取自配置，默认 xiaoyue）。 */
    private String myName() {
        String n = AiConfig.get().assistantName;
        return n == null || n.isBlank() ? "xiaoyue" : n;
    }

    /** 全身装备的指纹，用来判断有没有变化。 */
    private String equipmentSignature() {
        StringBuilder sb = new StringBuilder();
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            if (slot != net.minecraft.world.entity.EquipmentSlot.MAINHAND
                    && slot.getType() != net.minecraft.world.entity.EquipmentSlot.Type.ARMOR) {
                continue;
            }
            net.minecraft.world.item.ItemStack stack = this.getItemBySlot(slot);
            sb.append(stack.isEmpty() ? "-" : stack.getItem().toString()).append('|');
        }
        return sb.toString();
    }

    /** 把身上的装备说成一句话，比如“铁剑、铁头盔”。 */
    private String equipmentDescription() {
        StringBuilder sb = new StringBuilder();
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            if (slot != net.minecraft.world.entity.EquipmentSlot.MAINHAND
                    && slot.getType() != net.minecraft.world.entity.EquipmentSlot.Type.ARMOR) {
                continue;
            }
            net.minecraft.world.item.ItemStack stack = this.getItemBySlot(slot);
            if (stack.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append("、");
            }
            sb.append(stack.getHoverName().getString());
        }
        return sb.toString();
    }

    /** 自主行为：低血逃跑 / 自己吃 / 捡东西 / 天黑放火把。 */
    private void autonomousTick() {
        Player owner = this.getOwner();
        if (owner == null || !owner.isAlive() || this.resting) {
            return;
        }

        // ① 低血逃跑
        boolean lowHp = this.getHealth() <= 6.0F;
        boolean enemyNear = this.hasNearbyEnemy(16.0D);
        if (lowHp && enemyNear && this.autoState != 1) {
            this.autoState = 1;
            this.setTarget(null);
            ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                    this.myName() + " 血不多了，要往玩家身后躲");
        }
        if (this.autoState == 1) {
            this.setTarget(null);
            this.getNavigation().moveTo(owner, 1.4D);
            if (!lowHp || !enemyNear) {
                this.autoState = 0;
                ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                        this.myName() + " 躲过去了，安全了");
            }
            return;
        }

        // ② 自己吃东西回血
        if (this.getHealth() < this.getMaxHealth() * 0.6F) {
            for (int i = 0; i < this.bag.size(); i++) {
                net.minecraft.world.item.ItemStack food = this.bag.get(i);
                if (food.isEmpty() || !food.isEdible()) {
                    continue;
                }
                this.bag.set(i, net.minecraft.world.item.ItemStack.EMPTY);
                this.heal(4.0F);
                ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                        this.myName() + " 吃掉了背包里的 " + food.getHoverName().getString() + " 来回血");
                break;
            }
        }

        // ③ 捡地上的东西
        if (this.autoState == 0) {
            var drops = this.level().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                    this.getBoundingBox().inflate(8.0D),
                    net.minecraft.world.entity.Entity::isAlive);
            int free = 0;
            for (net.minecraft.world.item.ItemStack s : this.bag) {
                if (s.isEmpty()) {
                    free++;
                }
            }
            if (!drops.isEmpty() && free > 0) {
                if (!this.lootStarted) {
                    this.lootStarted = true;
                    ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                            this.myName() + " 看到地上有掉落物，要去捡");
                }
                net.minecraft.world.entity.item.ItemEntity target = drops.get(0);
                this.getNavigation().moveTo(target, 1.2D);
                if (this.distanceToSqr(target) < 2.5D) {
                    for (int i = 0; i < this.bag.size(); i++) {
                        if (this.bag.get(i).isEmpty()) {
                            this.bag.set(i, target.getItem().copy());
                            target.discard();
                            break;
                        }
                    }
                }
            } else if (this.lootStarted) {
                this.lootStarted = false;
                ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                        this.myName() + " 东西捡完了");
            }
        }

        // ④ 太黑了就插根火把（背包里有火把才做）
        long now = System.currentTimeMillis();
        if (now - this.lastTorchAt > 20_000L) {
            int light = this.level().getMaxLocalRawBrightness(this.blockPosition());
            if (light <= 6) {
                for (int i = 0; i < this.bag.size(); i++) {
                    net.minecraft.world.item.ItemStack stack = this.bag.get(i);
                    if (!stack.isEmpty() && stack.is(net.minecraft.world.item.Items.TORCH)) {
                        net.minecraft.core.BlockPos above = this.blockPosition().above();
                        if (this.level().getBlockState(above).isAir()) {
                            this.level().setBlockAndUpdate(above,
                                    net.minecraft.world.level.block.Blocks.TORCH.defaultBlockState());
                            this.bag.set(i, net.minecraft.world.item.ItemStack.EMPTY);
                            this.lastTorchAt = now;
                            ProactiveChat.fire(this.getServer(), this.ownerOrNull(),
                                    this.myName() + " 觉得太黑，插了一根火把");
                        }
                        break;
                    }
                }
            }
        }
    }

    /** 附近有没有敌对生物 */
    private boolean hasNearbyEnemy(double radius) {
        return !this.level().getEntitiesOfClass(Mob.class,
                this.getBoundingBox().inflate(radius),
                m -> m != this && m.isAlive() && m instanceof net.minecraft.world.entity.monster.Enemy).isEmpty();
    }

    /** 世界快照：给她“眼睛”，每次对话时调用一次。 */
    public String worldSnapshot() {
        StringBuilder sb = new StringBuilder();
        long t = this.level().getDayTime() % 24000L;
        String time = t < 12000L ? "白天" : (t < 13800L ? "傍晚" : "夜里");
        net.minecraft.core.BlockPos bp = this.blockPosition();
        sb.append("\n[环境] ").append(time)
                .append("，").append(this.level().isRaining() ? "下雨" : "晴")
                .append("，维度 ").append(this.level().dimension().location().getPath())
                .append("，坐标 ").append(bp.getX()).append(",").append(bp.getY()).append(",").append(bp.getZ());

        // 周围敌对生物
        var mobs = this.level().getEntitiesOfClass(Mob.class,
                this.getBoundingBox().inflate(16.0D),
                m -> m != this && m.isAlive() && m instanceof net.minecraft.world.entity.monster.Enemy);
        if (mobs.isEmpty()) {
            sb.append("\n[周围16格] 没有敌对生物");
        } else {
            java.util.Map<String, Integer> counts = new java.util.LinkedHashMap<>();
            for (Mob m : mobs) {
                counts.merge(m.getName().getString(), 1, Integer::sum);
            }
            StringBuilder names = new StringBuilder();
            int shown = 0;
            for (var e : counts.entrySet()) {
                if (shown++ >= 3) {
                    break;
                }
                if (names.length() > 0) {
                    names.append("、");
                }
                names.append(e.getKey()).append("×").append(e.getValue());
            }
            sb.append("\n[周围16格] 敌对生物：").append(names);
        }

        // 附近关键方块与矿石
        java.util.Map<String, Integer> keyBlocks = new java.util.LinkedHashMap<>();
        int ores = 0;
        for (net.minecraft.core.BlockPos pos : net.minecraft.core.BlockPos.betweenClosed(
                bp.offset(-8, -4, -8), bp.offset(8, 4, 8))) {
            net.minecraft.world.level.block.Block blk = this.level().getBlockState(pos).getBlock();
            if (blk == net.minecraft.world.level.block.Blocks.AIR) {
                continue;
            }
            if (blk instanceof net.minecraft.world.level.block.BedBlock) {
                keyBlocks.merge("床", 1, Integer::sum);
            } else if (blk == net.minecraft.world.level.block.Blocks.CRAFTING_TABLE) {
                keyBlocks.merge("工作台", 1, Integer::sum);
            } else if (blk == net.minecraft.world.level.block.Blocks.FURNACE
                    || blk == net.minecraft.world.level.block.Blocks.BLAST_FURNACE) {
                keyBlocks.merge("熔炉", 1, Integer::sum);
            } else if (blk == net.minecraft.world.level.block.Blocks.CHEST
                    || blk == net.minecraft.world.level.block.Blocks.BARREL) {
                keyBlocks.merge("箱子", 1, Integer::sum);
            } else if (blk instanceof net.minecraft.world.level.block.DoorBlock) {
                keyBlocks.merge("门", 1, Integer::sum);
            } else {
                var id = net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(blk);
                if (id != null && id.getPath().contains("_ore")) {
                    ores++;
                }
            }
        }
        if (keyBlocks.isEmpty() && ores == 0) {
            sb.append("\n[附近8格] 没什么特别的方块");
        } else {
            sb.append("\n[附近8格] ");
            boolean first = true;
            for (var e : keyBlocks.entrySet()) {
                if (!first) {
                    sb.append("、");
                }
                first = false;
                sb.append(e.getKey()).append("×").append(e.getValue());
            }
            if (ores > 0) {
                if (!first) {
                    sb.append("、");
                }
                sb.append("矿石×").append(ores);
            }
        }

        // 主人状态与视线
        Player owner = this.getOwner();
        if (owner != null) {
            var hit = owner.pick(8.0D, 0.0F, false);
            if (hit instanceof net.minecraft.world.phys.BlockHitResult bhr) {
                sb.append("\n[").append(owner.getName().getString()).append(" 正看着] ")
                        .append(this.level().getBlockState(bhr.getBlockPos()).getBlock()
                                .getName().getString());
            }
            sb.append("\n[").append(owner.getName().getString()).append(" 状态] 血=")
                    .append((int) Math.ceil(owner.getHealth())).append("/20，饥饿=")
                    .append(owner.getFoodData().getFoodLevel())
                    .append("，手持=").append(itemName(owner.getMainHandItem()));
        }
        return sb.toString();
    }

    /** 主人（转成服务端玩家，可能为空）。 */
    @Nullable
    private net.minecraft.server.level.ServerPlayer ownerOrNull() {
        Player p = this.getOwner();
        return p instanceof net.minecraft.server.level.ServerPlayer sp ? sp : null;
    }

    /** 把身上装备全交出去，返回交出的件数。 */
    public int giveEquipmentTo(net.minecraft.server.level.ServerPlayer player) {
        int count = 0;
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            if (slot != net.minecraft.world.entity.EquipmentSlot.MAINHAND
                    && slot.getType() != net.minecraft.world.entity.EquipmentSlot.Type.ARMOR) {
                continue;
            }
            net.minecraft.world.item.ItemStack stack = this.getItemBySlot(slot);
            if (stack.isEmpty()) {
                continue;
            }
            this.setItemSlot(slot, net.minecraft.world.item.ItemStack.EMPTY);
            net.minecraft.world.item.ItemStack copy = stack.copy();
            if (!player.getInventory().add(copy)) {
                player.drop(copy, false);
            }
            count++;
        }
        return count;
    }

    /** 给模型看的自检报告：身上有什么、血多少、在不在跟随。 */
    public String statusLine() {
        return "手持=" + itemName(this.getMainHandItem())
                + "，头=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD))
                + "，胸=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST))
                + "，腿=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.LEGS))
                + "，靴=" + itemName(this.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.FEET))
                + "，血=" + (int) Math.ceil(this.getHealth()) + "/" + (int) this.getMaxHealth()
                + "，状态=" + (this.isFollowing() ? "跟随中" : "原地站着");
    }

    private static String itemName(net.minecraft.world.item.ItemStack stack) {
        return stack == null || stack.isEmpty() ? "无" : stack.getHoverName().getString();
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (source.getEntity() instanceof net.minecraft.world.entity.LivingEntity attacker && attacker != this) {
            String who = attacker.getName().getString();
            net.minecraft.world.item.ItemStack weapon = attacker.getMainHandItem();
            String what = weapon.isEmpty() ? "空手" : weapon.getHoverName().getString();

            // 被打醒了 / 从坐着站起来
            if (this.resting) {
                boolean wasSleeping = this.sleptAt != null;
                this.sleptAt = null;
                this.standUp();
                AiNarrator.note(this.myName() + (wasSleeping ? " 被 " + who + " 打醒，站了起来"
                        : " 被打得站了起来"));
            }

            String situation = who + " 用 " + what + " 打了 " + this.myName() + " 一下";
            AiNarrator.note(situation);
            ProactiveChat.fire(this.getServer(), this.ownerOrNull(), situation);
            // 挨打了就立刻往主人身边跑
            Player owner = this.getOwner();
            if (owner != null && this.isFollowing()) {
                this.getNavigation().moveTo(owner, 1.3D);
            }
        }
        return super.hurt(source, amount);
    }

    @Override
    public boolean killedEntity(net.minecraft.server.level.ServerLevel level,
                                net.minecraft.world.entity.LivingEntity victim) {
        boolean result = super.killedEntity(level, victim);
        String name = victim.getName().getString();
        AiNarrator.note(this.myName() + " 打倒了 " + name);
        ProactiveChat.fire(level.getServer(), this.ownerOrNull(), this.myName() + " 刚打倒了 " + name);
        return result;
    }

    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        super.die(source);

        // 背包里的东西全掉出来
        if (!this.level().isClientSide) {
            for (int i = 0; i < this.bag.size(); i++) {
                net.minecraft.world.item.ItemStack stack = this.bag.get(i);
                if (!stack.isEmpty()) {
                    this.spawnAtLocation(stack);
                    this.bag.set(i, net.minecraft.world.item.ItemStack.EMPTY);
                }
            }
        }

        // 把死因写到聊天栏：原版的死亡描述（谁杀的、用什么、还是摔死/烧死）
        if (!this.level().isClientSide) {
            var server = this.getServer();
            if (server != null) {
                net.minecraft.network.chat.Component death = source.getLocalizedDeathMessage(this);
                server.getPlayerList().broadcastSystemMessage(
                        net.minecraft.network.chat.Component.literal("§c☠ ").append(death), false);
                AiNarrator.note(this.myName() + " 死了：" + death.getString());
            }
        }
    }

    /** 「过来」：走向某个玩家 */
    public void comeTo(Player target) {
        this.setFollowing(true);
        this.getNavigation().moveTo(target, 1.2D);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Following", this.isFollowing());
        if (this.ownerUuid != null) {
            tag.putUUID("Owner", this.ownerUuid);
        }
        net.minecraft.world.ContainerHelper.saveAllItems(tag, this.bag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Following")) {
            this.setFollowing(tag.getBoolean("Following"));
        }
        if (tag.hasUUID("Owner")) {
            this.ownerUuid = tag.getUUID("Owner");
        }
        net.minecraft.world.ContainerHelper.loadAllItems(tag, this.bag);
    }
}
