package com.shizuku.aihelper;

import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 客户端：右键小月打开对话界面（气泡改到渲染器里画了）。 */
@Mod.EventBusSubscriber(modid = AiHelperMod.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {
    }

    @SubscribeEvent
    public static void onUseKey(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || !event.isUseItem()) {
            return;
        }
        if (mc.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof XiaoyueEntity) {
            event.setCanceled(true);
            mc.setScreen(new XiaoyueChatScreen());
        }
    }
}
