package com.shizuku.aihelper;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Pose;
import org.joml.Matrix4f;

/**
 * 小月的渲染：细手臂玩家模型 + 手持物 + 护甲 + 头顶气泡。
 * 气泡挂在名字牌下面画，这样只要名字牌能显示，气泡就一定显示。
 */
public class XiaoyueRenderer extends LivingEntityRenderer<XiaoyueEntity, PlayerModel<XiaoyueEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AiHelperMod.MODID, "textures/entity/xiaoyue.png");

    public XiaoyueRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM), true), 0.5F);

        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(XiaoyueEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(XiaoyueEntity entity, float entityYaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int packedLight) {
        // 坐着的时候整体压低一点，看起来像坐着
        boolean crouching = entity.getPose() == Pose.CROUCHING;
        if (crouching) {
            pose.pushPose();
            pose.translate(0.0D, -0.45D, 0.0D);
        }
        super.render(entity, entityYaw, partialTick, pose, buffer, packedLight);
        if (crouching) {
            pose.popPose();
        }
    }

    /** 名字牌下面再画一行气泡。 */
    @Override
    protected void renderNameTag(XiaoyueEntity entity, Component displayName, PoseStack pose,
                                 MultiBufferSource buffer, int packedLight) {
        super.renderNameTag(entity, displayName, pose, buffer, packedLight);

        String say = entity.getSay();
        if (say == null || say.isBlank()) {
            return;
        }

        Font font = this.getFont();
        Minecraft mc = Minecraft.getInstance();

        pose.pushPose();
        pose.translate(0.0F, 10.0F, 0.0F);
        Matrix4f matrix = pose.last().pose();
        float width = font.width(say);
        int background = (int) (mc.options.getBackgroundOpacity(0.25F) * 255.0F) << 24;

        font.drawInBatch(say, -width / 2.0F, 0.0F, 0xFF66CCFF, false, matrix, buffer,
                Font.DisplayMode.SEE_THROUGH, background, packedLight);

        pose.popPose();
    }
}
