package com.shizuku.aihelper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.ClientChatEvent;

/**
 * 普通的聊天消息直接发给助手（不需要斜杠），以 / 开头的原版命令放行。
 * 有命令待确认时，只接管 y / n。
 */
public final class ChatHandler {
    private static String pendingCommand = null;

    private ChatHandler() {
    }

    public static void onChat(ClientChatEvent event) {
        AiConfig cfg = AiConfig.get();
        String raw = event.getMessage();

        // 0) /aiconfig 打开设置界面
        if (raw.trim().equalsIgnoreCase("/aiconfig")) {
            event.setCanceled(true);
            Minecraft.getInstance().execute(() -> Minecraft.getInstance().setScreen(new ConfigScreen(null)));
            return;
        }

        // 1) 有待确认的命令：只认 y / n
        if (pendingCommand != null) {
            String key = raw.trim().toLowerCase();
            if (key.equals("y") || key.equals("yes") || key.equals("是") || key.equals("好")) {
                event.setCanceled(true);
                execute(pendingCommand);
                pendingCommand = null;
                return;
            }
            if (key.equals("n") || key.equals("no") || key.equals("不") || key.equals("取消")) {
                event.setCanceled(true);
                pendingCommand = null;
                notice("§7取消啦");
                return;
            }
        }

        // 2) 以 / 开头的是原版命令，放行
        if (raw.startsWith("/")) {
            return;
        }

        // 3) chatMode=false 时，只有 prefix 开头的消息才交给助手
        String text = raw.trim();
        boolean prefixMode = !cfg.chatMode;
        if (prefixMode) {
            String prefix = cfg.prefix == null || cfg.prefix.isBlank() ? "/ai" : cfg.prefix.trim();
            if (!text.startsWith(prefix)) {
                return;
            }
            text = text.substring(prefix.length()).trim();
        }

        if (text.isEmpty()) {
            return;
        }

        // 前缀模式一定拦截（那条命令服务器本来也不认）；
        // 普通聊天模式看 forwardChat：true=照常发给服务器，false=只给助手看
        boolean forward = !prefixMode && cfg.forwardChat;
        if (!forward) {
            event.setCanceled(true);
        }

        if (!cfg.ready()) {
            notice("§c还没配置 API Key：打开 config/aihelper.json 把 apiKey 填上，然后重启游戏");
            return;
        }

        if (!forward) {
            notice(vanillaEcho(text));
        }
        AiService.chat(text)
                .thenAccept(reply -> Minecraft.getInstance().execute(() -> handleReply(reply)))
                .exceptionally(err -> {
                    Minecraft.getInstance().execute(() -> notice("§c请求失败：" + err.getMessage()));
                    return null;
                });
    }

    private static void handleReply(String rawReply) {
        JsonObject obj = parseJsonLoose(rawReply);
        if (obj == null) {
            // 模型偶尔不按 JSON 说话，那就把它当普通回复显示，别报错
            say(stripFences(rawReply).trim());
            return;
        }

        String reply = obj.has("reply") ? obj.get("reply").getAsString().trim() : "";
        String command = obj.has("command") ? obj.get("command").getAsString().trim() : "";

        if (!reply.isEmpty()) {
            say(reply);
        }

        if (command.isEmpty()) {
            return;
        }
        while (command.startsWith("/")) {
            command = command.substring(1);
        }

        AiConfig cfg = AiConfig.get();
        if (!cfg.isAllowed(command)) {
            notice("§c当前权限等级不允许执行：/" + command);
            return;
        }

        if (cfg.requireConfirm) {
            pendingCommand = command;
            notice("§7要执行：§e/" + command + " §7——输 y 确认，n 取消");
        } else {
            execute(command);
        }
    }

    private static void execute(String command) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) {
            notice("§c不在游戏里，没法执行");
            return;
        }
        mc.player.connection.sendCommand(command);
        notice("§a已执行：§e/" + command);
    }

    /** 助手自己说的话：默认也用 <名字> 的样式。 */
    private static void say(String text) {
        AiConfig cfg = AiConfig.get();
        String name = cfg.assistantName == null || cfg.assistantName.isBlank() ? "小月" : cfg.assistantName;
        String prefix = cfg.showName ? "<" + name + "> " : "";

        // broadcast=me / say 时，让服务器把这句转成可见的广播
        String mode = cfg.broadcast == null ? "off" : cfg.broadcast.trim().toLowerCase();
        if ((mode.equals("me") || mode.equals("say")) && Minecraft.getInstance().player != null) {
            String plain = plain(text);
            if (!plain.isEmpty()) {
                Minecraft.getInstance().player.connection.sendCommand(mode + " " + plain);
                return;
            }
        }
        send(prefix + text);
    }

    /** 广播用：去掉颜色代码、换行，压到 200 字以内。 */
    private static String plain(String text) {
        String t = text.replaceAll("§.", "").replace('\n', ' ').replace('\r', ' ').trim();
        return t.length() > 200 ? t.substring(0, 200) : t;
    }

    /** 宽松解析：从一堆文字里把第一个 {…} 抠出来解析，失败返回 null。 */
    private static JsonObject parseJsonLoose(String rawReply) {
        String text = stripFences(rawReply == null ? "" : rawReply).trim();
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start < 0 || end <= start) {
            return null;
        }
        try {
            return JsonParser.parseString(text.substring(start, end + 1)).getAsJsonObject();
        } catch (Exception e) {
            return null;
        }
    }

    /** 系统提示（报错、执行结果之类）：不带名字。 */
    private static void notice(String text) {
        send(text);
    }

    /** 模仿原版聊天：<玩家名> 说的话 */
    private static String vanillaEcho(String text) {
        Minecraft mc = Minecraft.getInstance();
        String name = mc.player != null ? mc.player.getGameProfile().getName() : "你";
        return "<" + name + "> " + text;
    }

    private static void send(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal(text), false);
        }
    }

    private static String stripFences(String text) {
        String t = text.trim();
        if (t.startsWith("```")) {
            t = t.replaceFirst("^```[a-zA-Z]*\\s*", "");
            if (t.endsWith("```")) {
                t = t.substring(0, t.length() - 3);
            }
        }
        return t.trim();
    }

    private static String shorten(String text) {
        String t = text == null ? "" : text.replace('\n', ' ');
        return t.length() > 120 ? t.substring(0, 120) + "…" : t;
    }
}
