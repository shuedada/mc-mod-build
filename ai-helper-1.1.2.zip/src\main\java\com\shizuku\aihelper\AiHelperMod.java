package com.shizuku.aihelper;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.logging.LogUtils;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;

/**
 * 入口。
 * 用法：聊天框直接说话就是跟助手聊天；按 K 打开设置界面。
 */
@Mod(AiHelperMod.MODID)
public final class AiHelperMod {
    public static final String MODID = "aihelper";
    public static final Logger LOGGER = LogUtils.getLogger();

    /** 默认 K 键打开设置，可以在“按键设置”里改 */
    public static final KeyMapping OPEN_CONFIG = new KeyMapping(
            "key.aihelper.config",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "key.categories.aihelper");

    public AiHelperMod() {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
            modBus.addListener(AiHelperMod::registerKeys);
            MinecraftForge.EVENT_BUS.addListener(AiHelperMod::onChat);
            MinecraftForge.EVENT_BUS.addListener(AiHelperMod::onKeyInput);
            LOGGER.info("AI Helper loaded: 直接聊天即可，按 K 打开设置");
        }
    }

    private static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN_CONFIG);
    }

    private static void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        while (OPEN_CONFIG.consumeClick()) {
            if (mc.screen == null) {
                mc.setScreen(new ConfigScreen(null));
            }
        }
    }

    private static void onChat(ClientChatEvent event) {
        ChatHandler.onChat(event);
    }
}
