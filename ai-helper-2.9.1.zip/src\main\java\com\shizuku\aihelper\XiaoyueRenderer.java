package com.shizuku.aihelper;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * 小月的渲染：标准玩家模型（粗手臂，配合 64x64 皮肤）+ 手持物 + 护甲，
 * 并且在她头顶画一个会跟着镜头转的气泡。
 */
public class XiaoyueRenderer extends LivingEntityRenderer<XiaoyueEntity, PlayerModel<XiaoyueEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AiHelperMod.MODID, "textures/entity/xiaoyue.png");
    private String lastLogged = "";

    public XiaoyueRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM), true), 0.5F);

        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_SLIM_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(XiaoyueEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(XiaoyueEntity entity, float entityYaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int packedLight) {
        super.render(entity, entityYaw, partialTick, pose, buffer, packedLight);

        String text = entity.getSay();
        if (text == null || text.isBlank()) {
            return;
        }
        if (!text.equals(this.lastLogged)) {
            this.lastLogged = text;
            AiHelperMod.LOGGER.info("[bubble] 正在绘制：{}", text);
        }

        Minecraft mc = Minecraft.getInstance();
        Font font = this.getFont();

        pose.pushPose();
        pose.translate(0.0D, entity.getBbHeight() + 0.95D, 0.0D);
        pose.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
        pose.scale(-0.025F, -0.025F, 0.025F);

        Matrix4f matrix = pose.last().pose();
        float width = font.width(text);
        int background = (int) (mc.options.getBackgroundOpacity(0.3F) * 255.0F) << 24;

        font.drawInBatch(text, -width / 2.0F, 0.0F, 0xFFFFFFFF, false, matrix, buffer,
                Font.DisplayMode.SEE_THROUGH, background, packedLight);

        pose.popPose();
    }
}
