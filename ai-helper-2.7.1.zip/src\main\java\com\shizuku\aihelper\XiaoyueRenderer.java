package com.shizuku.aihelper;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * 用玩家的模型渲染小月。
 * 继承 LivingEntityRenderer：翻转、受击红闪、阴影、名字牌都由原版处理；
 * 再挂上“手持物品”和“护甲”两层，让她能拿武器、穿装备。
 */
public class XiaoyueRenderer extends LivingEntityRenderer<XiaoyueEntity, PlayerModel<XiaoyueEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AiHelperMod.MODID, "textures/entity/xiaoyue.png");

    public XiaoyueRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5F);

        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(XiaoyueEntity entity) {
        return TEXTURE;
    }
}
