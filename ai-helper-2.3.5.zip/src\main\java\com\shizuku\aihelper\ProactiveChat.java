package com.shizuku.aihelper;

import net.minecraft.server.MinecraftServer;

/**
 * 主动开口：世界里发生大事（被打、主人被打、刚打赢）时，
 * 让她自己说一句，而不是等别人叫她。有冷却和开关，避免烧钱。
 */
public final class ProactiveChat {
    private static long lastFiredAt = 0L;

    private ProactiveChat() {
    }

    public static void fire(MinecraftServer server, String situation) {
        if (server == null) {
            return;
        }
        AiConfig cfg = AiConfig.get();
        if (!cfg.proactiveChat || !cfg.ready()) {
            return;
        }
        long now = System.currentTimeMillis();
        long cooldown = Math.max(5, cfg.proactiveCooldownSeconds) * 1000L;
        synchronized (ProactiveChat.class) {
            if (now - lastFiredAt < cooldown) {
                return;
            }
            lastFiredAt = now;
        }

        AiNarrator.note(situation);
        AiService.impulse(situation)
                .thenAccept(reply -> server.execute(() -> ServerChatHandler.proactiveReply(server, reply)))
                .exceptionally(err -> null);
    }
}
