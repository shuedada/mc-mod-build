package com.shizuku.aihelper;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * 小月的实体：玩家大小、会看向你、可以跟着你走或者站在原地。
 */
public class XiaoyueEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> DATA_FOLLOWING =
            SynchedEntityData.defineId(XiaoyueEntity.class, EntityDataSerializers.BOOLEAN);

    @Nullable
    private UUID ownerUuid;
    private int idleTicks;
    private net.minecraft.world.item.ItemStack lastMainHand = net.minecraft.world.item.ItemStack.EMPTY;
    private int lastOwnerHurtTime;
    private long lastFarNoteAt;

    public XiaoyueEntity(EntityType<? extends XiaoyueEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setCanPickUpLoot(true);
        this.xpReward = 0;
        // 死亡时身上装备全部掉落
        for (net.minecraft.world.entity.EquipmentSlot slot : net.minecraft.world.entity.EquipmentSlot.values()) {
            this.setDropChance(slot, 1.0F);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_FOLLOWING, Boolean.TRUE);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F, 1.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.5D));
    }

    public boolean isFollowing() {
        return this.entityData.get(DATA_FOLLOWING);
    }

    public void setFollowing(boolean value) {
        this.entityData.set(DATA_FOLLOWING, value);
    }

    public void setOwner(@Nullable Player player) {
        this.ownerUuid = player == null ? null : player.getUUID();
    }

    @Nullable
    public Player getOwner() {
        if (this.ownerUuid == null) {
            return null;
        }
        return this.level().getPlayerByUUID(this.ownerUuid);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }

        // 附近没人的时候慢慢“消失”
        int vanishSeconds = AiConfig.get().idleVanishSeconds;
        if (vanishSeconds > 0) {
            boolean someoneNear = !this.level().getEntitiesOfClass(
                    Player.class,
                    this.getBoundingBox().inflate(8.0D),
                    p -> p.isAlive() && !p.isSpectator()).isEmpty();
            if (someoneNear) {
                this.idleTicks = 0;
            } else {
                this.idleTicks++;
                if (this.idleTicks > vanishSeconds * 20) {
                    this.discard();
                    return;
                }
            }
        }

        // 只打“正在打主人”的生物：每 20 tick 扫一次
        Player ownerForCombat = this.getOwner();
        if (ownerForCombat != null && ownerForCombat.isAlive() && this.tickCount % 20 == 0) {
            if (this.getTarget() == null || !this.getTarget().isAlive()) {
                Mob attacker = this.level().getEntitiesOfClass(Mob.class,
                                this.getBoundingBox().inflate(16.0D),
                                m -> m != this && m.isAlive() && m.getTarget() == ownerForCombat)
                        .stream().findFirst().orElse(null);
                if (attacker != null) {
                    this.setTarget(attacker);
                    AiNarrator.note("我正在保护用户，攻击 " + attacker.getName().getString());
                }
            }
        }

        Player owner = this.getOwner();
        if (owner == null || !owner.isAlive()) {
            return;
        }

        // 旁白：主人挨打 / 装备变化 / 距离太远
        if (owner.hurtTime > 0 && this.lastOwnerHurtTime == 0) {
            AiNarrator.note("用户正在挨打");
            ProactiveChat.fire(this.getServer(), "用户正在挨打");
        }
        this.lastOwnerHurtTime = owner.hurtTime;

        if (this.tickCount % 20 == 0) {
            net.minecraft.world.item.ItemStack now = this.getMainHandItem();
            if (!net.minecraft.world.item.ItemStack.matches(now, this.lastMainHand)) {
                AiNarrator.note(now.isEmpty()
                        ? "用户把武器收走了"
                        : "用户给了你 " + now.getHoverName().getString());
                this.lastMainHand = now.copy();
            }
        }

        // 捡地上的装备：对应格子空着就直接穿上
        if (this.tickCount % 20 == 0) {
            for (net.minecraft.world.entity.item.ItemEntity drop :
                    this.level().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                            this.getBoundingBox().inflate(4.0D))) {
                if (!drop.isAlive()) {
                    continue;
                }
                net.minecraft.world.item.ItemStack stack = drop.getItem();
                net.minecraft.world.entity.EquipmentSlot slot =
                        Mob.getEquipmentSlotForItem(stack);
                if (slot == null || !this.getItemBySlot(slot).isEmpty()) {
                    continue;
                }
                this.setItemSlot(slot, stack.copy());
                this.setDropChance(slot, 1.0F);
                drop.discard();
                AiNarrator.note("我捡起并装备了 " + stack.getHoverName().getString());
            }
        }

        double distSq = this.distanceToSqr(owner);
        if (distSq > 576.0D) {
            long nowMs = System.currentTimeMillis();
            if (nowMs - this.lastFarNoteAt > 10_000L) {
                this.lastFarNoteAt = nowMs;
                AiNarrator.note("用户离我太远了");
            }
        }

        // 站定时不跟过去
        if (!this.isFollowing()) {
            return;
        }
        if (distSq > 576.0D) {
            if (this.tickCount % 40 == 0) {
                // 只有真的走丢（24 格以上）才传送，平时让她自己走
                this.teleportTo(owner.getX(), owner.getY(), owner.getZ());
                this.setDeltaMovement(0, 0, 0);
            }
        } else if (distSq > 16.0D && this.tickCount % 10 == 0) {
            this.getNavigation().moveTo(owner, 1.1D);
        }
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (source.getEntity() instanceof net.minecraft.world.entity.LivingEntity attacker && attacker != this) {
            AiNarrator.note("我被 " + attacker.getName().getString() + " 攻击了");
            ProactiveChat.fire(this.getServer(), "我被 " + attacker.getName().getString() + " 攻击了");
        }
        return super.hurt(source, amount);
    }

    @Override
    public boolean killedEntity(net.minecraft.server.level.ServerLevel level,
                                net.minecraft.world.entity.LivingEntity victim) {
        boolean result = super.killedEntity(level, victim);
        String name = victim.getName().getString();
        AiNarrator.note("我打倒了 " + name);
        ProactiveChat.fire(level.getServer(), "我刚打倒了 " + name);
        return result;
    }

    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        AiNarrator.note("我被打倒了");
        super.die(source);
    }

    /** 「过来」：走向某个玩家 */
    public void comeTo(Player target) {
        this.setFollowing(true);
        this.getNavigation().moveTo(target, 1.2D);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Following", this.isFollowing());
        if (this.ownerUuid != null) {
            tag.putUUID("Owner", this.ownerUuid);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Following")) {
            this.setFollowing(tag.getBoolean("Following"));
        }
        if (tag.hasUUID("Owner")) {
            this.ownerUuid = tag.getUUID("Owner");
        }
    }
}
