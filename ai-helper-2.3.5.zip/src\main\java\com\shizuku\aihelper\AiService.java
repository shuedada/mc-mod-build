package com.shizuku.aihelper;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.CompletableFuture;

/** 调用 DeepSeek：既能聊天，也能把需求翻译成一条 Minecraft 命令。 */
public final class AiService {
    private static final String ENDPOINT = "https://api.deepseek.com/chat/completions";
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    /** 最近几轮对话（role/content 的 JSON 对象）。 */
    private static final Deque<JsonObject> HISTORY = new ArrayDeque<>();

    private AiService() {
    }

    public static void resetHistory() {
        HISTORY.clear();
    }

    /** 主动开口：没人说话，但发生了事，让她自己说一句。 */
    public static CompletableFuture<String> impulse(String situation) {
        return chat("（没有人正在跟你说话。刚刚发生：" + situation
                + "。你可以主动开口说一句，简短自然，不要复述这条提示。）");
    }

    public static CompletableFuture<String> chat(String text) {
        AiConfig cfg = AiConfig.get();

        JsonArray messages = new JsonArray();
        messages.add(systemMessage(cfg));
        synchronized (HISTORY) {
            for (JsonObject h : HISTORY) {
                messages.add(h);
            }
        }
        // 把期间发生的“旁白”一起带上
        String notes = AiNarrator.drain();
        String userContent = notes.isEmpty() ? text : notes + "\n" + text;

        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", userContent);
        messages.add(user);

        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model);
        body.addProperty("temperature", 0.6);
        body.addProperty("max_tokens", 400);
        body.add("messages", messages);

        HttpRequest request = HttpRequest.newBuilder(URI.create(ENDPOINT))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + cfg.apiKey)
                .timeout(Duration.ofSeconds(60))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        return "{\"reply\":\"（接口出错 " + response.statusCode() + "："
                                + shorten(response.body()) + "）\"}";
                    }
                    try {
                        JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
                        String content = root.getAsJsonArray("choices").get(0).getAsJsonObject()
                                .getAsJsonObject("message").get("content").getAsString();

                        synchronized (HISTORY) {
                            HISTORY.add(copy(user));
                            JsonObject assistant = new JsonObject();
                            assistant.addProperty("role", "assistant");
                            assistant.addProperty("content", content);
                            HISTORY.add(assistant);
                            while (HISTORY.size() > Math.max(2, AiConfig.get().historyTurns * 2)) {
                                HISTORY.pollFirst();
                            }
                        }
                        return content;
                    } catch (Exception e) {
                        return "{\"reply\":\"（解析响应失败：" + e.getMessage() + "）\"}";
                    }
                });
    }

    private static JsonObject copy(JsonObject src) {
        JsonObject out = new JsonObject();
        out.addProperty("role", src.get("role").getAsString());
        out.addProperty("content", src.get("content").getAsString());
        return out;
    }

    private static JsonObject systemMessage(AiConfig cfg) {
        String roots = String.join(", ", cfg.allowedRoots());
        String prompt = """
                %s

                你现在在《我的世界》Java 版 1.20.1 里，通过聊天框跟玩家说话。你要同时做两件事：
                1. 像朋友一样自然地回话——短句、口语、有自己的情绪，别每次都很热情。
                2. 如果玩家想让你做事（要东西、传送、改天气、召唤生物……），就给出一条原版命令。

                输出规则（必须严格遵守）：
                - 只输出一个 JSON 对象，不要代码块标记，不要额外解释。
                - 格式：{"reply": "回给玩家的话"}
                - 如果要执行命令：{"reply": "回给玩家的话", "command": "不带斜杠的命令"}
                - 命令只能用这些：%s
                - 玩家自己的选择器用 @s。
                - 物品 ID 用 1.20.1 正确的命名空间写法，例如 diamond_sword、minecraft:golden_apple。
                - 做不到的事情就只在 reply 里说，不要编造命令。

                关于 [旁白]：那是游戏世界的状态播报，不是玩家说的话。比如
                [旁白] 用户给了你一把铁剑；用户在挨打
                意思是“刚刚发生了这些事”，你可以自然地回应或行动，但不要把它当成有人在跟你说话。
                """.formatted(cfg.persona, roots);

        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", prompt);
        return system;
    }

    private static String shorten(String text) {
        if (text == null) {
            return "";
        }
        String t = text.replace('\n', ' ');
        return t.length() > 120 ? t.substring(0, 120) + "…" : t;
    }
}
