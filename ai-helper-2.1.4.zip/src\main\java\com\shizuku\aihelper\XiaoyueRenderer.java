package com.shizuku.aihelper;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * 用玩家的模型渲染小月。
 * 继承 LivingEntityRenderer，这样翻转、受击红闪、阴影、名字牌都由原版处理。
 */
public class XiaoyueRenderer extends LivingEntityRenderer<XiaoyueEntity, PlayerModel<XiaoyueEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AiHelperMod.MODID, "textures/entity/xiaoyue.png");

    public XiaoyueRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(XiaoyueEntity entity) {
        return TEXTURE;
    }
}
