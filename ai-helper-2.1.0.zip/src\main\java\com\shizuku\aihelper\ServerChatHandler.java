﻿package com.shizuku.aihelper;

import com.google.gson.JsonObject;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 服务端逻辑：谁在聊天里提到「小月」，就由服务器去问 AI，
 * 然后把回复广播给所有人，必要时以服务器权限执行命令。
 *
 * 房主装了这个 mod，其他人什么都不用装。
 */
public final class ServerChatHandler {
    /** 每个玩家待确认的命令 */
    private static final Map<UUID, String> PENDING = new ConcurrentHashMap<>();
    private static volatile long lastCallAt = 0L;
    /** 两次请求之间的最小间隔，防止刷屏烧钱 */
    private static final long MIN_INTERVAL_MS = 1500L;

    private ServerChatHandler() {
    }

    @SubscribeEvent
    public static void onServerChat(ServerChatEvent event) {
        AiConfig cfg = AiConfig.get();
        MinecraftServer server = event.getPlayer().getServer();
        String message = event.getMessage().getString();
        if (message == null || message.isBlank() || server == null) {
            return;
        }

        ServerPlayer player = event.getPlayer();

        // 1) 有待确认的命令：这个玩家说 y / 好 就执行
        String pending = PENDING.get(player.getUUID());
        if (pending != null) {
            String key = message.trim().toLowerCase(Locale.ROOT);
            if (key.equals("y") || key.equals("yes") || key.equals("是") || key.equals("好")) {
                PENDING.remove(player.getUUID());
                execute(server, pending);
                return;
            }
            if (key.equals("n") || key.equals("no") || key.equals("不") || key.equals("取消")) {
                PENDING.remove(player.getUUID());
                broadcast(server, "§7好，那就不做了");
                return;
            }
        }

        // 2) 没提到名字就不理
        if (!mentionsName(message, cfg)) {
            return;
        }

        // 先处理“动作类”指令，这类不用问 AI
        String text = stripName(message, cfg);
        XiaoyueEntity entity = ensureEntity(server, player);
        if (entity != null && handleMovementIntent(server, entity, player, text)) {
            return;
        }

        if (!cfg.ready()) {
            broadcast(server, "§c还没填 API Key：房主按 K 打开设置，或者改 config/aihelper.json");
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastCallAt < MIN_INTERVAL_MS) {
            return;
        }
        lastCallAt = now;

        String asker = player.getGameProfile().getName();

        AiService.chat("[" + asker + "] " + text)
                .thenAccept(reply -> server.execute(() -> handleReply(server, player, reply)))
                .exceptionally(err -> {
                    server.execute(() -> broadcast(server, "§c请求失败：" + err.getMessage()));
                    return null;
                });
    }

    /** 在玩家附近找小月，没有就生成一个。 */
    private static XiaoyueEntity ensureEntity(MinecraftServer server, ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level)) {
            return null;
        }
        List<XiaoyueEntity> found = level.getEntitiesOfClass(XiaoyueEntity.class, player.getBoundingBox().inflate(64.0D));
        if (!found.isEmpty()) {
            return found.get(0);
        }
        EntityType<XiaoyueEntity> type = ModEntities.XIAOYUE.get();
        XiaoyueEntity entity = type.create(level);
        if (entity == null) {
            return null;
        }
        entity.moveTo(player.getX() + 1.0D, player.getY(), player.getZ() + 1.0D, player.getYRot(), 0.0F);
        entity.setOwner(player);
        level.addFreshEntity(entity);
        broadcast(server, "§7小月出现了");
        return entity;
    }

    /** 「过来」「跟着我」「站住」这类，直接动实体。 */
    private static boolean handleMovementIntent(MinecraftServer server, XiaoyueEntity entity, ServerPlayer player, String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        if (lower.contains("过来") || lower.contains("来我身边") || lower.contains("来这儿")) {
            entity.comeTo(player);
            say(server, "来了来了");
            return true;
        }
        if (lower.contains("站住") || lower.contains("别动") || lower.contains("站着别动") || lower.contains("原地")) {
            entity.setFollowing(false);
            entity.getNavigation().stop();
            say(server, "行，就站这儿");
            return true;
        }
        if (lower.contains("跟着我") || lower.contains("跟我走") || lower.contains("跟上")) {
            entity.setFollowing(true);
            say(server, "跟紧了");
            return true;
        }
        return false;
    }

    private static void handleReply(MinecraftServer server, ServerPlayer player, String rawReply) {
        JsonObject obj = ChatHandler.parseLoose(rawReply);
        if (obj == null) {
            say(server, rawReply.trim());
            return;
        }

        String reply = obj.has("reply") ? obj.get("reply").getAsString().trim() : "";
        String command = obj.has("command") ? obj.get("command").getAsString().trim() : "";

        if (!reply.isEmpty()) {
            say(server, reply);
        }

        if (command.isEmpty()) {
            return;
        }
        while (command.startsWith("/")) {
            command = command.substring(1);
        }

        AiConfig cfg = AiConfig.get();
        if (!cfg.isAllowed(command)) {
            broadcast(server, "§7（这条命令超过权限等级，没执行：" + command + "）");
            return;
        }

        if (cfg.requireConfirm) {
            PENDING.put(player.getUUID(), command);
            broadcast(server, "§7要执行：§e/" + command + " §7——" + player.getGameProfile().getName() + " 说 y 确认，n 取消");
        } else {
            execute(server, command);
        }
    }

    private static void execute(MinecraftServer server, String command) {
        try {
            CommandSourceStack source = server.createCommandSourceStack()
                    .withPermission(4)
                    .withSuppressedOutput();
            server.getCommands().performPrefixedCommand(source, command);
            broadcast(server, "§7（已执行 /" + command + "）");
        } catch (Exception e) {
            broadcast(server, "§c执行失败：" + e.getMessage());
        }
    }

    private static void say(MinecraftServer server, String text) {
        AiConfig cfg = AiConfig.get();
        String name = cfg.assistantName == null || cfg.assistantName.isBlank() ? "xiaoyue" : cfg.assistantName;
        String line = (cfg.showName ? "<" + name + "> " : "") + text;
        broadcast(server, line);
    }

    private static void broadcast(MinecraftServer server, String text) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(text), false);
    }

    /** 这些词出现就算在叫它 */
    private static boolean mentionsName(String message, AiConfig cfg) {
        String lower = message.toLowerCase(Locale.ROOT);
        if (lower.contains("小月") || lower.contains("xiaoyue")) {
            return true;
        }
        String name = cfg.assistantName;
        return name != null && !name.isBlank() && lower.contains(name.toLowerCase(Locale.ROOT));
    }

    /** 把称呼去掉，剩下的话再交给模型 */
    private static String stripName(String message, AiConfig cfg) {
        String text = message;
        for (String token : new String[]{"小月", "xiaoyue", cfg.assistantName}) {
            if (token == null || token.isBlank()) {
                continue;
            }
            text = text.replace(token, " ");
            text = text.replace(token.toUpperCase(Locale.ROOT), " ");
        }
        text = text.replaceAll("\\s{2,}", " ").trim();
        return text.isEmpty() ? message : text;
    }
}
