package com.shizuku.aihelper;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * 用玩家的模型渲染小月：64x64 皮肤，外层（帽子/外套/袖子）一起画。
 */
public class XiaoyueRenderer extends EntityRenderer<XiaoyueEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AiHelperMod.MODID, "textures/entity/xiaoyue.png");

    private final PlayerModel<XiaoyueEntity> model;

    public XiaoyueRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false);
        this.shadowRadius = 0.5F;
    }

    @Override
    public ResourceLocation getTextureLocation(XiaoyueEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(XiaoyueEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();

        this.model.attackTime = 0.0F;
        this.model.crouching = false;
        this.model.riding = false;
        this.model.young = false;
        this.model.setupAnim(entity, 0.0F, 0.0F, entity.tickCount + partialTick, entityYaw, 0.0F);

        VertexConsumer consumer = buffer.getBuffer(this.model.renderType(TEXTURE));
        this.model.renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY,
                1.0F, 1.0F, 1.0F, 1.0F);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }
}
